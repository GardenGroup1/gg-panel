#!/usr/bin/env python3
"""Local Hermes bridge. Never prints API credentials or invokes a shell."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import urllib.request
import urllib.error

API = 'http://127.0.0.1:3012/internal/hermes'
KEY = Path('/etc/gg-panel-hermes.key')

def message_ref():
    platform = os.environ.get('HERMES_SESSION_PLATFORM', '')
    chat = os.environ.get('HERMES_SESSION_CHAT_ID', '')
    message = os.environ.get('HERMES_SESSION_MESSAGE_ID', '')
    if platform and chat and message:
        return 'hermes:' + hashlib.sha256(f'{platform}:{chat}:{message}'.encode()).hexdigest()
    return None

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['context','capture','status','draft_get','draft_update','draft_accept','drafts'])
    parser.add_argument('--file', type=Path)
    parser.add_argument('--request-id', help='Stable explicit ID for a non-gateway test or resumed capture')
    args = parser.parse_args()
    body = json.loads(args.file.read_text()) if args.file else {}
    if not isinstance(body, dict): raise ValueError('Expected a JSON object')
    body['action'] = args.action
    if args.action in ('capture','status'):
        part = body.pop('part', 1)
        if not isinstance(part, int) or isinstance(part, bool) or not 1 <= part <= 50: raise ValueError('part must be 1..50')
        ref = args.request_id or body.get('requestId') or message_ref()
        if not ref: raise ValueError('No originating message ID. Use the captureRef from context; do not invent a new ID on a retry.')
        body['requestId'] = ref + ':' + str(part)
    req = urllib.request.Request(API, data=json.dumps(body,ensure_ascii=False).encode(), headers={
        'Content-Type':'application/json', 'X-GG-Hermes-Key':KEY.read_text().strip()
    })
    try:
        with urllib.request.urlopen(req, timeout=115) as response: result=json.load(response)
    except (urllib.error.URLError,TimeoutError):
        result={'ok':False,'code':'transport','error':'Ответ не получен. Черновик мог сохраниться. Проверьте status с тем же requestId или draft_get с тем же id; не создавайте новый.'}
    if args.action == 'context': result['captureRef'] = message_ref()
    print(json.dumps(result,ensure_ascii=False))
    return 0 if result.get('ok') else 1

if __name__ == '__main__':
    try: sys.exit(main())
    except (ValueError, OSError, json.JSONDecodeError) as exc:
        print(json.dumps({'ok':False,'error':str(exc)},ensure_ascii=False));sys.exit(1)
