#!/usr/bin/env python3
from pathlib import Path
import datetime
import json
import os
import pwd
import secrets
import shutil
import subprocess
import yaml

root=Path('/root/.hermes')
backup=root/'backups'/('before-gg-tasks-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d-%H%M%S'))
backup.mkdir(mode=0o700,parents=True)
for name in ['config.yaml','SOUL.md']:
    shutil.copy2(root/name,backup/name)
key=Path('/etc/gg-panel-hermes.key')
if not key.exists():
    fd=os.open(key,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o640)
    with os.fdopen(fd,'w') as f:f.write(secrets.token_urlsafe(48)+'\n')
os.chown(key,0,pwd.getpwnam('gg-panel').pw_gid);key.chmod(0o640)
skill=root/'skills/productivity/gg-tasks'
skill.mkdir(parents=True,exist_ok=True)
shutil.copy2('/srv/gg-panel/hermes/SKILL.md',skill/'SKILL.md')
config_path=root/'config.yaml'
config=yaml.safe_load(config_path.read_text())
stt=config.setdefault('stt',{})
stt.update({'enabled':True,'provider':'local','language':'ru'})
local=stt.setdefault('local',{})
local.update({'model':'base','device':'cpu','compute_type':'int8','language':'ru','unload_after_idle_seconds':120})
config_path.write_text(yaml.safe_dump(config,allow_unicode=True,sort_keys=False));config_path.chmod(0o600)
soul=root/'SOUL.md'
text=soul.read_text()
marker='## Поручения Garden Group через Telegram'
if marker not in text:
    text+='''\n\n## Поручения Garden Group через Telegram
При просьбе записать/поставить задачу Garden Group, текстом или голосом, обязательно загрузи навык gg-tasks из /root/.hermes/skills/productivity/gg-tasks/SKILL.md. Сначала сохрани поручение в Инбокс через этот навык. Затем одним сообщением уточни недостающие направление, дедлайн (или без срока) и приоритет A/B/C/D; размер XS/S/M/L/XL оцени сам. Уже названное не спрашивай повторно. После ответа владельца отправь существующий черновик в задачу без лишнего подтверждения. Не путай черновик с задачей в Google: утверждай создание только по подтверждённому taskId. Для этого процесса не используй локальный Kanban, память или файлы-планы вместо панели. Не выполняй само поручение и не отправляй его исполнителю, если владелец просит лишь записать задачу. Обычные вопросы и разработка «Зелёные здесь» сохраняют свой прежний порядок работы. Обращайся к владельцу «Шеф».\n'''
    soul.write_text(text);soul.chmod(0o600)
print(json.dumps({'skill':'gg-tasks','stt':{'provider':stt['provider'],'language':stt['language'],'model':local['model']},'backup':str(backup)},ensure_ascii=False))
