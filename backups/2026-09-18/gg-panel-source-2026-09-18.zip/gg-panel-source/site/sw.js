// Only this panel's public shell is cached. API responses stay on the network.
const VERSION = '2026-09-18-panel-restore-17';
const PREFIX = 'gg-panel:' + self.registration.scope + ':';
const CACHE = PREFIX + VERSION;
const SHELL = ['./', './index.html', './manifest.json', './icon-192.png',
  './icon-512.png', './icon-maskable-512.png', './apple-touch-icon.png'];
const pageURL = new URL('./index.html', self.registration.scope).href;
const rootURL = new URL(self.registration.scope);
const isPanelPage = url => url.origin === rootURL.origin &&
  (url.pathname === rootURL.pathname || url.href.split('?')[0].split('#')[0] === pageURL);

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE);
    await cache.addAll(SHELL.map(path => new Request(new URL(path, self.registration.scope), {cache:'reload'})));
    await self.skipWaiting();
  })());
});
self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(key => key.startsWith(PREFIX) && key !== CACHE).map(key => caches.delete(key)));
    await self.clients.claim();
    const clients = await self.clients.matchAll({type:'window'});
    clients.forEach(client => {
      const url = new URL(client.url);
      if (!isPanelPage(url)) return;
      client.postMessage({type:'GG_PANEL_UPDATE_READY', version:VERSION});
      // A legacy cache-first worker can serve old HTML even for the recovery link.
      // Reload ONLY clients that explicitly requested an app update; protect open drafts.
      if (url.searchParams.has('update')) {
        // Never await navigation during activation: its fetch waits for activation to end.
        void client.navigate(url.href).catch(() => {});
      }
    });
  })());
});

async function panelResponse(request, event) {
  const cache = await caches.open(CACHE);
  const saved = await cache.match(pageURL);
  const network = fetch(request, {cache:'no-store'}).then(async response => {
    if (response.ok && !response.redirected && (response.headers.get('content-type') || '').includes('text/html')) {
      try { await cache.put(pageURL, response.clone()); } catch { /* Quota must not prevent an online load. */ }
      return response;
    }
    return saved || response;
  }).catch(() => saved || new Response('Нет интернета. Откройте панель после подключения.', {
    status:503, headers:{'Content-Type':'text/plain; charset=utf-8'}
  }));
  // Keep a slow successful response for the next opening even after serving offline HTML.
  event.waitUntil(network.then(() => {}));
  if (!saved) return network;
  let timer;
  const fallback = new Promise(resolve => { timer = setTimeout(() => resolve(saved), 2000); });
  try { return await Promise.race([network, fallback]); } finally { clearTimeout(timer); }
}

self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  if (event.request.method !== 'GET' || url.origin !== rootURL.origin ||
      !url.href.startsWith(self.registration.scope) || url.pathname === '/api' ||
      url.pathname.startsWith('/api/') || url.pathname === '/health') return;
  if (isPanelPage(url)) {
    event.respondWith(panelResponse(event.request, event));
    return;
  }
  if (event.request.mode === 'navigate') return;
  event.respondWith(caches.open(CACHE).then(async cache => (await cache.match(event.request)) || fetch(event.request)));
});
