import { existsSync, readFileSync, writeFileSync, renameSync } from 'node:fs';
import { join } from 'node:path';

const DAY = 86400000, WINDOW = 2 * 3600000;
const ORIGIN = 'https://garden-group.online';
const normalize = v => String(v ?? '').trim().toLowerCase().replace(/ё/g,'е').replace(/[\s_]+/g,' ');
const round = n => Math.round((n + Number.EPSILON) * 100) / 100;
const utcDay = v => new Date(v).toISOString().slice(0,10);
const offsetDay = (d,n) => utcDay(Date.parse(d+'T00:00:00Z') + n*DAY);
const PAYMENT_STATUS = { 'получен':'accepted','получено':'accepted','возвращен':'returned','возврат':'returned','ожидается':'expected','пополнение баланса':'tobalance','списание с баланса':'frombalance','начисление на депозит':'returned_to_balance' };
const ORDER_STATUS = { 'завершен':'payed','завершён':'payed','частично оплачен':'part_payed','новый':'new','отменен':'cancelled','ложный':'false','ожидаем оплаты':'payment_waiting','в работе':'in_work','ожидаем возврата':'waiting_for_return','не подтвержден':'not_confirmed','отложен':'pending' };
export function parseMoney(value) {
  if (typeof value === 'number' && Number.isFinite(value)) return round(value);
  const s = String(value ?? '').replace(/[\s\u00a0\u202f]/g,'').replace(/(?:руб\.?|₽|RUB|USD|EUR|KZT|BYN|\$|€)$/i,'').replace(',', '.');
  if (!/^-?\d+(?:\.\d{1,2})?$/.test(s)) throw Error('Не распознана сумма в выгрузке GetCourse.');
  return round(Number(s));
}
export function parseDay(value) {
  const s = String(value ?? '').trim();
  let date;
  if (/^\d{4}-\d{2}-\d{2}(?:[ T]|$)/.test(s)) date = s.slice(0,10);
  else { const m=s.match(/^(\d{2})\.(\d{2})\.(\d{4})(?:\s|$)/); if(m)date=`${m[3]}-${m[2]}-${m[1]}`; }
  if (!date || !Number.isFinite(Date.parse(date+'T00:00:00Z')) || utcDay(Date.parse(date+'T00:00:00Z')) !== date) throw Error('Не распознана дата в выгрузке GetCourse.');
  return date;
}
export function normalizeExport(kind, info, defaultCurrency = 'RUB') {
  if (!Array.isArray(info?.fields) || !Array.isArray(info?.items) || info.items.length > 50000) throw Error('Неожиданный формат выгрузки GetCourse.');
  const headers = info.fields.map(f => normalize(typeof f === 'string' ? f : f?.title || f?.name));
  function column(names, required = true) {
    for (const name of names) { const i=headers.indexOf(normalize(name)); if(i>=0)return i; }
    if (required) throw Error('В выгрузке не найдено поле «'+names[0]+'». Нужна проверка формата.');
    return -1;
  }
  // Observed school payment export uses «Номер» as the stable payment identifier.
  const id = column(kind==='payments'?['ID','ID платежа','payment_id','Номер']:['ID','ID заказа','deal_id','Номер']);
  const created = column(kind==='payments'?['Создан','Дата создания','Создано','created_at']:['Дата создания','Создан','Создано','created_at']);
  const status = column(['Статус','status']);
  let amount = column(kind==='payments'?['Сумма','Сумма платежа','amount']:['Стоимость','Сумма заказа','cost'],false);
  let amountCurrency='';
  if(amount<0 && kind==='deals') {
    amount=headers.findIndex(h=>/^стоимость,\s*[a-z]{3}$/.test(h));
    if(amount>=0)amountCurrency=headers[amount].match(/[a-z]{3}$/)[0].toUpperCase();
  }
  if(amount<0)throw Error('В выгрузке не найдено поле «Сумма / Стоимость». Нужна проверка формата.');
  const currency = column(['Валюта','currency'],false);
  const product = kind==='deals'?column(['Состав заказа','Предложения','Название','Позиции заказа','product_title'],false):-1;
  const method = kind==='payments'?column(['Тип платежа','Тип','payment_type','type']):-1;
  const paid = kind==='deals'?column(['Оплачен','is_payed','deal_is_paid'],false):-1;
  const records = new Map();
  for (const row of info.items) {
    if (!Array.isArray(row) || row.length < headers.length) throw Error('Неполная строка в выгрузке GetCourse.');
    const recordId=String(row[id]??'').trim(); if(!recordId)throw Error('В выгрузке нет идентификатора записи.');
    // A column explicitly denominated in RUB is authoritative even for a foreign-currency order.
    const rowCurrency = amountCurrency || (currency>=0 ? String(row[currency] || '').trim().toUpperCase() : /\b(USD|EUR|KZT|BYN)\b/i.exec(String(row[amount]))?.[1]?.toUpperCase() || defaultCurrency);
    if (!/^[A-Z]{3}$/.test(rowCurrency)) throw Error('Не распознана валюта в выгрузке.');
    const rawStatus=normalize(row[status]), mapped=(kind==='payments'?PAYMENT_STATUS:ORDER_STATUS)[rawStatus] || String(row[status]??'').trim().toLowerCase();
    if (kind==='payments' && !['accepted','returned','expected','tobalance','frombalance','returned_to_balance'].includes(mapped)) throw Error('Неизвестный статус платежа. Требуется проверка расчётов.');
    const r={id:recordId,date:parseDay(row[created]),status:mapped,amount:parseMoney(row[amount]),currency:rowCurrency};
    if(kind==='deals') {
      r.product=product>=0?String(row[product] || 'Без названия').slice(0,600):'Состав заказа не указан';
      // The UI calls this metric completed orders, which is distinct from the payment flag.
      r.paid=mapped==='payed';
      r.paymentMarked=paid>=0 ? ['да','true','1'].includes(normalize(row[paid])) : null;
    } else r.method=method>=0?String(row[method] || ''):'';
    const previous=records.get(recordId);
    if(previous && JSON.stringify(previous)!==JSON.stringify(r))throw Error('Противоречивые строки с одинаковым ID. Снимок не обновлён.');
    records.set(recordId,r);
  }
  // Contact details and custom fields are deliberately discarded before persistence.
  return [...records.values()];
}
export function aggregate(snapshot, from, to, currency) {
  const countDays = Math.floor((Date.parse(to)-Date.parse(from))/DAY)+1;
  const payments=snapshot.payments.filter(p=>p.date>=from && p.date<=to && p.currency===currency);
  const deals=snapshot.deals.filter(p=>p.date>=from && p.date<=to && p.currency===currency && p.amount>0 && p.status!=='false');
  const internal=p=>/^(internal|virtual|внутренний сч[её]т|бонусный сч[её]т)$/i.test(p.method.trim());
  const received=payments.filter(p=>p.status==='accepted' && !internal(p));
  const returned=payments.filter(p=>p.status==='returned' && !internal(p));
  const receivedAmount=round(received.reduce((s,p)=>s+p.amount,0));
  const returnedAmount=round(returned.reduce((s,p)=>s+Math.abs(p.amount),0));
  const paidOrders=deals.filter(d=>d.paid).length;
  const summary={receivedAmount,returnedAmount,paymentCount:received.length,orders:deals.length,paidOrders,
    averagePayment:received.length?round(receivedAmount/received.length):null,paidShare:deals.length?round(paidOrders/deals.length*100):null,
    orderAmount:round(deals.reduce((s,d)=>s+d.amount,0))};
  const days=Array.from({length:countDays},(_,i)=>({date:offsetDay(from,i),received:0,returned:0,count:0}));
  const byDay=new Map(days.map(d=>[d.date,d]));
  for(const p of received){const d=byDay.get(p.date);d.received=round(d.received+p.amount);d.count++;}
  for(const p of returned){const d=byDay.get(p.date);d.returned=round(d.returned+Math.abs(p.amount));}
  const products=new Map();
  for(const d of deals){const p=products.get(d.product)||{name:d.product,orders:0,paidOrders:0,orderAmount:0};p.orders++;p.paidOrders+=d.paid?1:0;p.orderAmount=round(p.orderAmount+d.amount);products.set(d.product,p);}
  const statusNames={payed:'Завершены',part_payed:'Частично оплачены',new:'Новые',cancelled:'Отменены',payment_waiting:'Ожидают оплаты',in_work:'В работе',waiting_for_return:'Ожидают возврата',not_confirmed:'Не подтверждены',pending:'Отложены'};
  const statuses=new Map();for(const d of deals)statuses.set(d.status,(statuses.get(d.status)||0)+1);
  return {summary,days,products:[...products.values()].sort((a,b)=>b.orderAmount-a.orderAmount).slice(0,10),
    statuses:[...statuses].map(([status,count])=>({status,name:statusNames[status]||status,count})).sort((a,b)=>b.count-a.count)};
}

export function createGetCourse({dataDir,now=Date.now,fetchImpl=fetch,startTimer=true}={}) {
  const configFile=join(dataDir,'getcourse-config.json'), stateFile=join(dataDir,'getcourse-state.json');
  let config=existsSync(configFile)?JSON.parse(readFileSync(configFile,'utf8')):null;
  let state=existsSync(stateFile)?JSON.parse(readFileSync(stateFile,'utf8')):{snapshot:null,job:null,nextSync:0,requests:[],error:''};
  let busy=false,timer;
  function save(file,value){writeFileSync(file+'.tmp',JSON.stringify(value),{mode:0o600});renameSync(file+'.tmp',file);}
  function persist(){save(stateFile,state);}
  function today(){return new Intl.DateTimeFormat('sv-SE',{timeZone:'Europe/Moscow',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(now()));}
  async function request(path,filters={}) {
    state.requests=state.requests.filter(t=>t>now()-WINDOW);
    if(state.requests.length>=20)throw Error('Достигнут лимит запросов этой панели. Следующая попытка через два часа.');
    state.requests.push(now());persist();
    const url=new URL('/pl/api/account/'+path,ORIGIN);url.searchParams.set('key',config.key);
    for(const[k,v]of Object.entries(filters))url.searchParams.set(k,v);
    const res=await fetchImpl(url,{redirect:'error',headers:{Accept:'application/json'},signal:AbortSignal.timeout(45000)});
    if(!res.ok)throw Error('GetCourse временно недоступен. Сохранён предыдущий отчёт.');
    let data;
    if(res.body?.getReader){const reader=res.body.getReader();const chunks=[];let n=0;while(true){const{done,value}=await reader.read();if(done)break;n+=value.length;if(n>18*1024*1024){await reader.cancel();throw Error('Выгрузка слишком большая. Нужна настройка более короткого периода.');}chunks.push(Buffer.from(value));}data=JSON.parse(Buffer.concat(chunks).toString('utf8'));}
    else data=await res.json();
    return data;
  }
  function startJob(){const to=today();state.job={from:offsetDay(to,-89),to,kind:'payments',exportId:null,attempts:0,nextPoll:now(),parts:{}};state.error='';persist();}
  async function tick(){
    if(!config || busy || (!state.job && state.nextSync>now()) || state.job?.nextPoll>now())return;
    busy=true;
    try {
      if(!state.job)startJob();const job=state.job;
      if(!job.exportId){
        const r=await request(job.kind,{'created_at[from]':job.from,'created_at[to]':job.to});
        const id=r.info?.export_id ?? r.result?.export_id;
        if(!(r.success===true || r.success==='true') || !/^[0-9]+$/.test(String(id)))throw Error('GetCourse не запустил экспорт. Проверьте ключ и доступность выгрузки в аккаунте.');
        job.exportId=String(id);job.nextPoll=now()+15000;persist();return;
      }
      const r=await request('exports/'+job.exportId);
      if(r.success===true || r.success==='true'){
        const info=r.info || r.result;
        job.parts[job.kind]=normalizeExport(job.kind,info,config.currency);
        if(job.kind==='payments'){job.kind='deals';job.exportId=null;job.attempts=0;job.nextPoll=now()+15000;persist();return;}
        state.snapshot={...job.parts,from:job.from,to:job.to,syncedAt:new Date(now()).toISOString()};
        state.job=null;state.nextSync=now()+WINDOW;state.error='';persist();return;
      }
      const message=String(r.error_message||r.error||'');
      if(Number(r.error_code)===909 || /не заверш[её]н|not (?:yet )?ready|в процессе/i.test(message)){
        if(++job.attempts>7)throw Error('GetCourse ещё готовит выгрузку. Повторим позже.');
        job.nextPoll=now()+Math.min(120000,15000*2**job.attempts);persist();return;
      }
      if(/файл не создан|ни одного|нет (?:данных|объектов)/i.test(message))throw Error('GetCourse не сформировал файл. Пустой ответ не заменяет сохранённые показатели.');
      throw Error('GetCourse отклонил выгрузку. Проверьте ключ и лимиты запросов.');
    }catch(e){state.error=/^В |^Не |^GetCourse |^Достигнут |^Выгрузка |^Неполная |^Неожиданный |^Противоречивые /.test(e.message)?e.message:'Не удалось обновить GetCourse. Сохранён предыдущий отчёт.';state.job=null;state.nextSync=now()+WINDOW;persist();}
    finally{busy=false;}
  }
  function status(){return{configured:!!config,account:'gardenschool7',schoolUrl:ORIGIN,syncing:!!state.job,lastSync:state.snapshot?.syncedAt||null,error:state.error||'',nextSync:state.nextSync?new Date(state.nextSync).toISOString():null,coverage:state.snapshot?{from:state.snapshot.from,to:state.snapshot.to}:null,today:today(),defaultCurrency:config?.currency||'RUB'};}
  function metrics(body){
    const s=status();if(!state.snapshot)return{ok:true,status:s,report:null};
    let from,to;
    try{to=parseDay(body.to||state.snapshot.to);from=parseDay(body.from||offsetDay(to,-29));}catch(e){return{ok:false,code:'input',error:e.message};}
    if(from>to || from<state.snapshot.from || to>state.snapshot.to)return{ok:false,code:'range',error:'Выберите период внутри загруженных дат: '+state.snapshot.from+' — '+state.snapshot.to,status:s};
    const currencies=[...new Set([...state.snapshot.payments,...state.snapshot.deals].map(r=>r.currency))].sort();
    const currency=body.currency||config.currency;
    if(!/^[A-Z]{3}$/.test(currency))return{ok:false,code:'input',error:'Неверная валюта.'};
    const report=aggregate(state.snapshot,from,to,currency);
    const n=Math.round((Date.parse(to)-Date.parse(from))/DAY)+1,previousFrom=offsetDay(from,-n),previousTo=offsetDay(from,-1);
    report.previous=previousFrom>=state.snapshot.from?aggregate(state.snapshot,previousFrom,previousTo,currency).summary:null;
    return{ok:true,status:s,report:{...report,from,to,currency,currencies:currencies.length?currencies:[currency],previousFrom,previousTo}};
  }
  async function action(body){
    if(body.action==='gc_configure'){
      if(state.snapshot)return{ok:false,code:'configured',error:'GetCourse уже подключён. Замену ключа выполнит администратор сервера.'};
      if(busy || state.job)return{ok:false,code:'busy',error:'Дождитесь завершения текущей проверки ключа.'};
      if(typeof body.key!=='string' || !/^[A-Za-z0-9_-]{20,512}$/.test(body.key.trim()))return{ok:false,code:'input',error:'Вставьте полный секретный ключ GetCourse.'};
      config={key:body.key.trim(),currency:'RUB',account:'gardenschool7'};save(configFile,config);state.nextSync=0;void tick();return{ok:true,status:status()};
    }
    if(body.action==='gc_refresh'){
      if(!config)return{ok:false,code:'config',error:'Сначала подключите GetCourse.'};
      if(!state.job && state.nextSync<=now()){void tick();}
      return{ok:true,status:status()};
    }
    return metrics(body);
  }
  if(startTimer){timer=setInterval(()=>{void tick();},15000);timer.unref();void tick();}
  return{action,tick,status,close(){clearInterval(timer);}};
}
