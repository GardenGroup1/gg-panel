  gcStatus:{configured:false,syncing:false,lastSync:null,error:'',today:''},gcReport:null,gcLoading:false,gcConnecting:false,gcError:'',gcOffline:false,gcKey:'',gcRetryKey:false,
  gcFrom:'2026-08-01',gcTo:'2026-08-31',gcCurrency:'RUB',gcPreset:'custom',gcSelectedDay:null,
  gcPresets:[{id:'7d',label:'7 дней'},{id:'30d',label:'30 дней'},{id:'month',label:'Этот месяц'}],
  gcCards:[{key:'receivedAmount',label:'Полученные платежи',money:true,help:'Со статусом «Получен»'},{key:'returnedAmount',label:'Возвращённые платежи',money:true,help:'Со статусом «Возвращён»'},{key:'averagePayment',label:'Средний платёж',money:true,help:'Среди полученных платежей'},{key:'orders',label:'Платные заказы',money:false,help:'Созданы в выбранном периоде'},{key:'paidOrders',label:'Завершённые заказы',money:false,help:'Из платных заказов периода'},{key:'paymentCount',label:'Получено платежей',money:false,help:'Частичные оплаты считаются отдельно'}],
  gcDate(date){if(!date)return '';return date.split('-').reverse().join('.');},
  gcMoney(value){if(value==null)return '—';try{return new Intl.NumberFormat('ru-RU',{style:'currency',currency:this.gcReport?.currency||this.gcCurrency,minimumFractionDigits:0,maximumFractionDigits:2}).format(value);}catch{return Number(value).toLocaleString('ru-RU');}},
  gcValue(key,money){const v=this.gcReport?.summary[key];return v==null?'—':money?this.gcMoney(v):Number(v).toLocaleString('ru-RU');},
  gcDelta(key,money){const a=this.gcReport?.summary[key],b=this.gcReport?.previous?.[key];if(a==null||b==null)return 'Нет данных для сравнения';const diff=a-b;return (diff>0?'+':'')+(money?this.gcMoney(diff):Number(diff).toLocaleString('ru-RU'))+' к предыдущему периоду';},
  get gcChartMax(){return Math.max(1,...(this.gcReport?.days||[]).flatMap(d=>[d.received,d.returned]));},
  chooseGcPeriod(preset,load=true){
    this.gcPreset=preset;const today=this.gcStatus.coverage?.to||this.gcStatus.today||new Date().toISOString().slice(0,10);this.gcTo=today;
    const d=new Date(today+'T12:00:00Z');if(preset==='month')d.setUTCDate(1);else d.setUTCDate(d.getUTCDate()-(preset==='7d'?6:29));
    this.gcFrom=d.toISOString().slice(0,10);if(load)this.loadGetCourse();
  },
  restoreGc(){try{const saved=JSON.parse(storage.get(STORAGE_PREFIX+'getcourse')||'null');if(saved?.report && saved?.status?.lastSync){this.gcReport=saved.report;this.gcStatus=saved.status;this.gcFrom=saved.report.from;this.gcTo=saved.report.to;this.gcCurrency=saved.report.currency;this.gcOffline=true;}}catch{}},
  async loadGetCourse(){
    if(!this.authed || this.gcLoading)return;
    if(!navigator.onLine){this.gcOffline=true;return;}
    this.gcLoading=true;this.gcError='';
    try{const r=await api('gc_metrics',{from:this.gcFrom||undefined,to:this.gcTo||undefined,currency:this.gcCurrency});if(!this.authed)return;
      if(!r.ok){this.gcError=r.error;if(r.status)this.gcStatus=r.status;this.gcOffline=['network','offline'].includes(r.code);return;}this.gcStatus=r.status;this.gcOffline=false;
      if(r.report){this.gcReport=r.report;this.gcFrom=r.report.from;this.gcTo=r.report.to;this.gcCurrency=r.report.currency;this.gcSelectedDay=null;
        if(!storage.set(STORAGE_PREFIX+'getcourse',JSON.stringify({status:r.status,report:r.report})))this.gcError='Отчёт загружен, но браузер не разрешил сохранить его для чтения офлайн.';
      }else if(!this.gcFrom)this.chooseGcPeriod('30d',false);
    }finally{this.gcLoading=false;}
  },
  async connectGetCourse(){
    if(this.gcConnecting||!navigator.onLine)return;this.gcConnecting=true;this.gcError='';
    try{const r=await api('gc_configure',{key:this.gcKey});this.gcKey='';if(!r.ok){this.gcError=r.error;return;}this.gcStatus=r.status;this.gcRetryKey=false;await this.loadGetCourse();}finally{this.gcConnecting=false;}
  },
