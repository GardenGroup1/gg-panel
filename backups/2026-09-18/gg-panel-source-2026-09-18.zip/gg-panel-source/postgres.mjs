import pg from 'pg';
import {existsSync,readFileSync,writeFileSync,renameSync} from 'node:fs';
import {join} from 'node:path';

const { Pool } = pg;
const REQUIRED = ['DB_HOST','DB_PORT','DB_NAME','DB_USER','DB_PASSWORD','DB_TABLE'];
const number = value => value == null ? null : Number(value);
const iso = value => value instanceof Date ? value.toISOString() : value == null ? null : String(value);

function tableName(value) {
  const parts=String(value||'').split('.');
  if(!parts.length||parts.length>2||parts.some(part=>!/^[A-Za-z_][A-Za-z0-9_]*$/.test(part)))throw Error('invalid_table');
  return parts.map(part=>'"'+part+'"').join('.');
}

function normalizeRows(rows) {
  const numeric=['calls','incoming','outgoing','newClients','uniqueContacts','talked','talkSec','avgTalkSec','avgAnswerSec','aiScored','aiScoreAvg','scoreGreeting','scoreQualification','scorePresentation','scoreObjections','scoreClosing','managerTalkRatio','complaints','highComplaints','attention','processingErrors','resolutionKnown','resolved'];
  return rows.map(row=>Object.fromEntries(Object.entries(row).map(([key,value])=>[key,numeric.includes(key)?number(value):iso(value)])));
}

export function createPostgresMetrics({env=process.env,PoolImpl=Pool,now=Date.now,startTimer=false,interval=300000,dataDir=''}={}) {
  const missing=REQUIRED.filter(key=>!env[key]);
  const snapshotFile=dataDir?join(dataDir,'postgres-metrics.json'):'';
  let pool=null,report=null,lastError='',refreshing=null,timer=null,lastAttempt=0;
  if(snapshotFile&&existsSync(snapshotFile)){try{const saved=JSON.parse(readFileSync(snapshotFile,'utf8'));if(saved?.schema===1&&saved.kind==='calls'&&Array.isArray(saved.months)&&Array.isArray(saved.days))report=saved;}catch{}}
  function persistReport(){if(!snapshotFile||!report)return;writeFileSync(snapshotFile+'.tmp',JSON.stringify(report),{mode:0o600});renameSync(snapshotFile+'.tmp',snapshotFile);}
  const configured=!missing.length;
  if(configured){
    const sslMode=(env.DB_SSLMODE||'disable').toLowerCase();
    pool=new PoolImpl({
      host:env.DB_HOST,port:Number(env.DB_PORT),database:env.DB_NAME,user:env.DB_USER,password:env.DB_PASSWORD,
      ssl:sslMode==='disable'?false:{rejectUnauthorized:sslMode==='verify-full'},max:2,idleTimeoutMillis:30000,
      connectionTimeoutMillis:10000,options:'-c default_transaction_read_only=on -c statement_timeout=20000',
      application_name:'gg-panel-metrics'
    });
    pool.on?.('error',error=>console.error('Postgres pool error:',error?.code||error?.name||'unknown'));
  }
  let table='';
  try{if(configured)table=tableName(env.DB_TABLE);}catch{lastError='Некорректно указана таблица анализатора звонков.';}
  const common=`
    count(*)::int as "calls",
    count(*) filter (where lower(trim(call_type)) in ('incoming','входящий'))::int as "incoming",
    count(*) filter (where lower(trim(call_type)) in ('outgoing','исходящий'))::int as "outgoing",
    count(*) filter (where lower(trim(is_new_client)) in ('1','true','да'))::int as "newClients",
    count(distinct case when lower(trim(call_type)) in ('incoming','входящий') then nullif(from_number,'') else nullif(to_number,'') end)::int as "uniqueContacts",
    count(*) filter (where talk_duration_sec>0)::int as "talked",
    coalesce(sum(talk_duration_sec),0)::int as "talkSec",
    round(avg(talk_duration_sec) filter (where talk_duration_sec>=0),1) as "avgTalkSec",
    round(avg(answer_time_sec) filter (where answer_time_sec>=0),1) as "avgAnswerSec",
    count(*) filter (where ai_score is not null)::int as "aiScored",
    round(avg(ai_score) filter (where ai_score is not null),1) as "aiScoreAvg",
    round(avg(score_greeting) filter (where score_greeting is not null),1) as "scoreGreeting",
    round(avg(score_qualification) filter (where score_qualification is not null),1) as "scoreQualification",
    round(avg(score_presentation) filter (where score_presentation is not null),1) as "scorePresentation",
    round(avg(score_objections) filter (where score_objections is not null),1) as "scoreObjections",
    round(avg(score_closing) filter (where score_closing is not null),1) as "scoreClosing",
    round(avg(talk_ratio_manager) filter (where talk_ratio_manager is not null),1) as "managerTalkRatio",
    count(*) filter (where client_complaint_detected is true)::int as "complaints",
    count(*) filter (where complaint_severity='высокая')::int as "highComplaints",
    count(*) filter (where requires_management_attention is true)::int as "attention",
    count(*) filter (where processing_status='error')::int as "processingErrors",
    count(*) filter (where nullif(trim(resolution_status),'') is not null)::int as "resolutionKnown",
    count(*) filter (where resolution_status='решено')::int as "resolved"`;

  async function refresh(){
    if(!configured||!pool||!table||refreshing)return refreshing||false;
    lastAttempt=now();
    refreshing=(async()=>{
      try{
        const base=`coalesce(nullif(trim(subdivision),''),'Не определено')`;
        const monthlySql=`select to_char(date_trunc('month',call_date),'YYYY-MM') period,
          case when grouping(${base})=1 then '__all__' else ${base} end subdivision,${common}
          from ${table} where call_date>=current_date-interval '370 days'
          group by date_trunc('month',call_date), grouping sets ((${base}),())
          order by date_trunc('month',call_date),subdivision`;
        const dailySql=`select call_date::text date,
          case when grouping(${base})=1 then '__all__' else ${base} end subdivision,${common}
          from ${table} where call_date>=current_date-interval '95 days'
          group by call_date, grouping sets ((${base}),()) order by call_date,subdivision`;
        const infoSql=`select min(call_date)::text "from",max(call_date)::text "through",count(*)::int rows,max(processed_at) "sourceUpdatedAt" from ${table}`;
        const [monthly,daily,info]=await Promise.all([pool.query(monthlySql),pool.query(dailySql),pool.query(infoSql)]);
        const summary=info.rows[0];
        report={
          schema:1,kind:'calls',mode:startTimer?'online':'manual',updatePolicy:startTimer?'timer':'manual',title:'Анализатор звонков · PostgreSQL',
          refreshedAt:new Date(now()).toISOString(),sourceUpdatedAt:iso(summary.sourceUpdatedAt),
          range:{from:summary.from,through:summary.through,rows:number(summary.rows)},refreshMinutes:startTimer?Math.round(interval/60000):null,
          directionMap:{'Бюро':['Бюро'],'Питомник':['Питомник'],'ЛК и Питомник Тюмень':['Тюмень Строй']},
          unmappedSubdivisions:['ЛК','Не определено'],months:normalizeRows(monthly.rows),days:normalizeRows(daily.rows),
          notes:[
            'Выгрузка содержит только отвеченные звонки; долю пропущенных по этой таблице определить нельзя.',
            'Подразделение «ЛК» не связано автоматически с Томском или Бали: для этого нужен отдельный справочник.',
            'В Пульт передаются только агрегаты. Номера телефонов, расшифровки и тексты AI-комментариев остаются в базе.'
          ]
        };
        lastError='';persistReport();return true;
      }catch(error){lastError='Не удалось обновить агрегаты анализатора звонков. Сохранённые показатели остаются доступны.';console.error('Postgres refresh failed:',error?.code||error?.name||'unknown');return false;}
    })().finally(()=>{refreshing=null});
    return refreshing;
  }
  function snapshotReply(){
    if(startTimer&&configured&&now()-lastAttempt>=interval&&!refreshing)void refresh();
    if(!configured)return {ok:false,code:'unconfigured',error:'PostgreSQL анализатора звонков ещё не настроен на сервере.'};
    if(!report)return {ok:false,code:refreshing?'warming':'unavailable',error:lastError||'Сервер получает агрегаты анализатора звонков.'};
    return {ok:true,report,stale:!!lastError||(startTimer&&now()-Date.parse(report.refreshedAt)>interval*2),warning:lastError,syncing:!!refreshing,manual:!startTimer};
  }
  if(configured&&table&&startTimer){void refresh();timer=setInterval(()=>void refresh(),interval);timer.unref();}
  return {configured,refresh,snapshotReply,close(){if(timer)clearInterval(timer);void pool?.end?.();}};
}
