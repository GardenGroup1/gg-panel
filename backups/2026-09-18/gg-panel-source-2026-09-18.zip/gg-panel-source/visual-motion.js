(()=>{
  if(document.querySelector('.gg-scroll-progress'))return;
  const progress=document.createElement('div');progress.className='gg-scroll-progress';progress.innerHTML='<i></i>';document.body.prepend(progress);
  const bar=progress.firstElementChild,reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
  const update=()=>{const max=document.documentElement.scrollHeight-innerHeight;bar.style.transform=`scaleX(${max>0?scrollY/max:0})`};
  addEventListener('scroll',update,{passive:true});update();
  if(reduce)return;
  const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('gg-in');observer.unobserve(entry.target)}}),{threshold:.08,rootMargin:'0px 0px -20px'});
  const revealSelector='.gg-reveal,.task-home>.card,.task-home>.grid>.card,.aa-stat,.aa-box,.aa-webinar,.business-direction-card,.beta-notice,.workspace-hero,.pulse-view>.grid>.card,.tasks-view .dcard,.tasks-view .quad,.inbox-view>.space-y-3>.card,.call-kpi,.call-dashboard-head,.call-control-card,.inventory-dashboard-head,.inventory-kpi,.inventory-writeoff';
  const surfaceSelector='.aa-stat,.aa-box,.business-direction-card,.pulse-view>.grid>.card';
  const decorate=root=>root.querySelectorAll?.(surfaceSelector).forEach(el=>{if(el.dataset.ggSurface)return;el.dataset.ggSurface='1';el.classList.add('gg-surface');el.addEventListener('pointermove',event=>{const r=el.getBoundingClientRect();el.style.setProperty('--gg-x',`${event.clientX-r.left}px`);el.style.setProperty('--gg-y',`${event.clientY-r.top}px`)},{passive:true})});
  const scan=root=>{root.querySelectorAll?.(revealSelector).forEach(el=>{if(el.dataset.ggObserved)return;el.dataset.ggObserved='1';el.classList.add('gg-motion');observer.observe(el)});decorate(root)};
  const start=()=>{scan(document);new MutationObserver(records=>records.forEach(r=>r.addedNodes.forEach(n=>n.nodeType===1&&scan(n)))).observe(document.body,{childList:true,subtree:true})};
  document.readyState==='loading'?addEventListener('DOMContentLoaded',start,{once:true}):start();
})();
