from pathlib import Path
import shutil, re

ROOT = Path(__file__).resolve().parent
APP_VERSION = '2026-09-08-finance-10'
SITE = ROOT / 'site'
SITE.mkdir(exist_ok=True)
for p in (ROOT.parent / 'gg-panel-pwa/site').iterdir():
    shutil.copy2(p, SITE / p.name)
html = (SITE / 'index.html').read_text()
html = re.sub(r"const API_URL = window.PANEL_API_URL \|\| '[^']+';", "const API_URL = '/api';", html)
html = html.replace("const timeout = setTimeout(() => controller.abort(), 45000);", "const timeout = setTimeout(() => controller.abort(), ['list','refresh'].includes(action) ? 15000 : 120000);")
html = html.replace("online: navigator.onLine, stale: true, lastSync: null, offlineReady: false, cacheError: '',", "online: navigator.onLine, stale: true, lastSync: null, offlineReady: false, cacheError: '', loadError: '', syncing: false, refreshTimer: null,")
html = html.replace("get readOnly(){ return !this.online || this.stale; },", """get hasData(){ return !!this.lastSync; },
  get readOnly(){ return !this.online || this.stale || !this.hasData; },
  get connectionLabel(){
    if (!this.hasData) return this.loading ? 'Получаем задачи…' : 'Задачи ещё не загружены';
    if (!this.online) return 'Нет интернета · сохранённые задачи · только чтение';
    if (this.stale) return 'Сохранённые задачи · только чтение';
    return this.syncing ? 'Подключено · обновляем данные из Google' : 'Подключено';
  },""")
html = html.replace("!online ? 'Нет интернета · только чтение' : stale ? 'Показана сохранённая копия · только чтение' : 'Подключено'", 'connectionLabel')
html = html.replace('<span x-show="offlineReady">· Приложение доступно офлайн</span>', '<span x-show="offlineReady && hasData && !cacheError">· Задачи сохранены на устройстве</span>')
html = html.replace('x-show="loading && !tasks.length"', 'x-show="false"')
html = html.replace('<main class="max-w-7xl mx-auto px-5 lg:px-8 pt-6">', '''<section x-show="!hasData" class="max-w-7xl mx-auto px-5 lg:px-8 py-8" role="status">
      <div class="card p-6 space-y-4">
        <h1 class="text-xl font-bold" x-text="loading ? 'Загружаем задачи' : 'Пока нет загруженных задач'"></h1>
        <p class="text-sm" x-text="!online ? 'Подключитесь к интернету для первой загрузки. На этом устройстве ещё нет сохранённых задач.' : loadError || 'Получаем подготовленный список с сервера.'"></p>
        <button class="btn btn-primary" @click="refresh()" :disabled="loading || !online">Повторить загрузку</button>
      </div>
    </section>
    <p x-show="hasData && loadError" x-text="loadError" class="max-w-7xl mx-auto px-5 lg:px-8 text-sm" role="status" style="color:#765019"></p>
    <main x-show="hasData" class="max-w-7xl mx-auto px-5 lg:px-8 pt-6">''')
html = html.replace("    if (this.authed) { this.restoreSnapshot(); await this.loadTasks(); }", """    this.refreshTimer=setInterval(()=>{
      if(this.authed && navigator.onLine && !document.hidden && !this.loading && !this.active && !this.showCreate)this.loadTasks(false,false,true);
    },15000);
    window.addEventListener('pageshow',()=>{if(this.authed && navigator.onLine)this.loadTasks();});
    document.addEventListener('visibilitychange',()=>{if(!document.hidden && this.authed && navigator.onLine)this.loadTasks();});
    if (this.authed) { this.restoreSnapshot(); await this.loadTasks(); }""")
html = html.replace("if (!snapshot || snapshot.api!==API_URL || !Array.isArray(snapshot.tasks)) return false;", "if (!snapshot || snapshot.api!==API_URL || !Array.isArray(snapshot.tasks) || !snapshot.savedAt || !Number.isFinite(Date.parse(snapshot.savedAt))) return false;")
html = html.replace("  persistSnapshot(){\n    const savedAt=new Date().toISOString();", "  persistSnapshot(at=this.lastSync){\n    const savedAt=at || new Date().toISOString();")
html = html.replace("  logout(){\n    storage.remove", "  logout(){\n    if(navigator.onLine)void api('logout');\n    storage.remove")
html = html.replace("this.showCreate=false;this.showCmd=false;this.lf.password='';this.lerr='';", "this.showCreate=false;this.showCmd=false;this.lf.password='';this.lerr='';this.loadError='';")
html = html.replace('  async loadTasks(fromLogin=false){', '  async loadTasks(fromLogin=false,force=false,quiet=false){')
html = html.replace("      const r=await api('list');", "      const r=await api(force?'refresh':'list');\n      if(!this.authed)return false;")
html = html.replace("if(r.code!=='auth')this.toast(r.error||'Сервер вернул неверный ответ.');", "this.loadError=r.error||'Сервер вернул неверный ответ.';\n        if(r.code!=='auth' && r.code!=='warming' && !quiet)this.toast(this.loadError);")
html = html.replace("this.stale=false;this.persistSnapshot();return true;", "this.stale=!!r.readOnly;this.syncing=!!r.syncing;this.loadError=r.warning||'';this.persistSnapshot(r.at);return true;")
html = re.sub(r'  inbox:\[[\s\S]*?\n  \],\n\n  async init', '  inbox:[],\n\n  async init', html, count=1)
html = html.replace("this.tasks=snapshot.tasks.map((t,i)=>this.hydrateTask(t,i));", "this.tasks=snapshot.tasks.map((t,i)=>this.hydrateTask(t,i));\n      this.inbox=Array.isArray(snapshot.inbox)?snapshot.inbox:[];")
html = html.replace('savedAt,tasks:this.tasks}', 'savedAt,tasks:this.tasks,inbox:this.inbox}')
html = html.replace("this.tasks=[];this.active=null;this.lastSync=null;", "this.tasks=[];this.inbox=[];this.active=null;this.lastSync=null;")
html = html.replace("      this.tasks=r.tasks.map((t,i)=>this.hydrateTask(t,i));", """      this.tasks=r.tasks.map((t,i)=>this.hydrateTask(t,i));
      this.inbox=(r.inbox||[]).map(it=>{
        const edited=this.inbox.find(old=>old.id===it.id && old._editing);
        return edited?{...it,...edited,state:it.state,warning:it.warning}:it;
      });""")
html = html.replace('Задачи из ТГ-бота, голосовых и встреч. Проверьте и подтвердите.', 'Поручения из Hermes. Здесь они хранятся, пока вы уточняете направление, срок и приоритет.')
html = html.replace('x-text="it.receivedAt"', 'x-text="new Date(it.receivedAt).toLocaleString(\'ru-RU\')"')
html = html.replace('<input x-model="it.task"', '<input @input="it._editing=true" :disabled="it.state!==\'draft\'" x-model="it.task"')
html = html.replace('<input x-model="it.owner"', '<input @input="it._editing=true" :disabled="it.state!==\'draft\'" x-model="it.owner"')
html = html.replace('<input x-model="it.deadline"', '<input @input="it._editing=true" :disabled="it.state!==\'draft\'" x-model="it.deadline"')
html = html.replace('<select x-model="it.direction" class="inp">', '<select @change="it._editing=true" :disabled="it.state!==\'draft\'" x-model="it.direction" class="inp"><option value="">Выберите направление</option>')
html = html.replace('<select x-model="it.prio" class="inp">', '<select @change="it._editing=true" :disabled="it.state!==\'draft\'" x-model="it.prio" class="inp">')
html = html.replace('<div class="flex justify-end gap-2 mt-4">\n                <button @click="rejectInbox', '''<p class="text-sm text-muted mt-2" x-text="'Размер: '+it.size+' · оценка Hermes'"></p>
              <p x-show="it.warning" x-text="it.warning" class="text-sm mt-2" style="color:#B33F35"></p>
              <div class="flex justify-end gap-2 mt-4">
                <button @click="rejectInbox''')
html = html.replace('<button @click="rejectInbox(it.id)" class="btn btn-ghost" :disabled="readOnly">Удалить</button>', '<button @click="rejectInbox(it.id)" class="btn btn-ghost" :disabled="!online || it._sending || it.state===\'saving\'">Убрать</button>')
html = html.replace('<button @click="acceptInbox(it.id)" class="btn btn-primary" :disabled="readOnly">Создать задачу</button>', '<button @click="acceptInbox(it.id)" class="btn btn-primary" :disabled="readOnly || it._sending || it.state!==\'draft\' || !it.direction" x-text="it._sending || it.state===\'saving\' ? \'Сохраняем…\' : \'Создать задачу\'"></button>')
start = html.index('  acceptInbox(id){')
end = html.index('  openCmd(){', start)
html = html[:start] + '''  async acceptInbox(id){
    if(!this.requireOnline())return;
    const it=this.inbox.find(i=>i.id===id);if(!it || it._sending || it.state!=='draft')return;
    if(!it.direction){this.toast('Выберите направление');return;}
    it._sending=true;
    try {
      const r=await api('inbox_accept',{id,task:it.task,direction:it.direction,owner:it.owner,deadline:it.deadline,prio:it.prio,size:it.size,block:it.block});
      if(!r.ok){this.toast(r.error);return;}
      it._editing=false;
      this.toast(r.status==='created'?'Задача создана в Google':r.warning||'Запись сохранена в Инбоксе');
      await this.loadTasks();
    } finally {it._sending=false;}
  },
  async rejectInbox(id){
    if(!navigator.onLine)return;
    const r=await api('inbox_dismiss',{id});
    if(!r.ok){this.toast(r.error);return;}
    this.inbox=this.inbox.filter(i=>i.id!==id);this.persistSnapshot();
    this.toast('Убрано из Инбокса');
  },
''' + html[end:]
html = html.replace("async refresh(){ if(await this.loadTasks())this.toast('Обновлено'); },", "async refresh(){ if(await this.loadTasks(false,true))this.toast(this.syncing?'Показаны сохранённые задачи. Обновляем из Google…':'Список получен с сервера'); },")
html = html.replace("    const r = await api('update', { id: t.id, patch });", "    const r = await api('update', { id: t.id, patch, expectedTask: previous?.task });")
# Avoid calling a demonstration AI result a real integration.
html = html.replace("this.toast('AI предложил 5 шагов. Правьте как нужно.');", "this.toast('Добавлен шаблон из 5 шагов. AI пока не подключён.');")
html = html.replace("register('sw.js')", "register('sw.js', {updateViaCache:'none'})")
html = re.sub(r"  // Регистрация Service Worker для PWA[\s\S]*?\n</script>",
    (ROOT/'pwa-register.js').read_text().replace('__APP_VERSION__',APP_VERSION)+'\n</script>', html, count=1)
if (ROOT / 'tailwind.css').exists():
    runtime = (ROOT.parent / 'gg-panel-pwa/build/tailwind.js').read_text().replace('</script','<\\/script')
    html = html.replace('<script>\n'+runtime+'\n</script>', '<style>'+ (ROOT/'tailwind.css').read_text()+'</style>')
    html = re.sub(r'<script>\s*tailwind\.config = [\s\S]*?</script>', '', html, count=1)
if (ROOT / 'fonts-inline.css').exists():
    html = re.sub(r'<link[^>]+href="https://fonts\.(?:googleapis|gstatic)\.com[^>]*>\n?', '', html)
    licenses = '\n\n'.join((ROOT / f).read_text() for f in ['Montserrat-OFL.txt','JetBrainsMono-OFL.txt'])
    html = html.replace('</head>', '<style>/*\n'+licenses.replace('*/','* /')+'\n*/\n'+(ROOT/'fonts-inline.css').read_text()+'</style>\n</head>')
# GetCourse is a separate cached view; it must open even before Google tasks load.
html = html.replace("{id:'inbox',t:'Инбокс'", "{id:'metrics',t:'Метрики Академии',icon:'bar-chart-3'},{id:'inbox',t:'Инбокс'")
html = html.replace('grid-template-columns:repeat(5,1fr)', 'grid-template-columns:repeat(6,1fr)')
html = html.replace('.bnav{max-width:640px;', '.bnav{max-width:720px;')
html = html.replace('  async init(){', (ROOT/'metrics-state.js').read_text()+'\n'+(ROOT/'academy-state.js').read_text()+'\n  async init(){', 1)
html = html.replace('</head>', '<style>'+(ROOT/'metrics.css').read_text()+'\n'+(ROOT/'academy.css').read_text()+'</style>\n</head>')
html = html.replace('      <!-- ===== СЕГОДНЯ ===== -->', (ROOT/'academy.html').read_text()+'\n'+(ROOT/'metrics.html').read_text()+'\n      <!-- ===== СЕГОДНЯ ===== -->')
html = html.replace('<main x-show="hasData"', '<main x-show="hasData || view===\'metrics\'"')
html = html.replace('<section x-show="!hasData"', '<section x-show="!hasData && view!==\'metrics\'"')
html = html.replace('x-show="hasData && loadError"', 'x-show="hasData && loadError && view!==\'metrics\'"')
html = html.replace('<div class="max-w-7xl mx-auto px-5 lg:px-8 pt-3" role="status"', '<div x-show="view!==\'metrics\'" class="max-w-7xl mx-auto px-5 lg:px-8 pt-3" role="status"')
html = html.replace('<button @click="refresh()" class="btn btn-ghost btn-icon" title="Обновить">', '<button @click="view===\'metrics\'?refreshAcademy():refresh()" class="btn btn-ghost btn-icon" title="Обновить">')
html = html.replace('<button @click="openCmd()"', '<button x-show="view!==\'metrics\'" @click="openCmd()"')
html = html.replace('<button @click="openCreate()"', '<button x-show="view!==\'metrics\'" @click="openCreate()"')
html = html.replace('<div class="fab"', '<div x-show="view!==\'metrics\'" class="fab"')
html = html.replace('<div class="ml-auto flex items-center gap-1.5">', '<div class="ml-auto flex items-center gap-1.5"><button x-show="view===\'metrics\'" class="btn btn-ghost" @click="logout()">Выйти</button>')
html = html.replace("['list','refresh'].includes(action)", "['list','refresh','academy_metrics','gc_metrics','gc_refresh','gc_configure'].includes(action)")
html = html.replace('storage.remove(SNAPSHOT_KEY);', "storage.remove(SNAPSHOT_KEY);storage.remove(STORAGE_PREFIX+'getcourse');storage.remove(STORAGE_PREFIX+'academy');")
html = html.replace('this.tasks=[];this.inbox=[];', "this.gcReport=null;this.gcStatus={configured:false};this.gcKey='';this.gcFrom='';this.gcTo='';this.gcError='';this.tasks=[];this.inbox=[];")
html = html.replace("    if (!API_URL) {", "    if(location.hash.startsWith('#metrics')){this.view='metrics';const tab=location.hash.split('/')[1];if(this.academyTabs.some(t=>t.id===tab))this.academyTab=tab;}\n    this.$watch('view',v=>{if(v==='metrics'){this.selectAcademyTab(this.academyTab);this.restoreAcademy();this.refreshAcademy();}else history.replaceState(null,'','#'+v);});\n    if (!API_URL) {")
html = html.replace("this.online=false;this.stale=true;this.showCreate=false;", "this.online=false;this.stale=true;this.gcOffline=true;this.academyOffline=!!this.academyData;this.showCreate=false;")
html = html.replace('if(this.authed)this.loadTasks();', "if(this.authed){this.loadTasks();if(this.view==='metrics')this.refreshAcademy();}")
html = html.replace('this.loadTasks(false,false,true);', "this.view==='metrics'?this.refreshAcademy():this.loadTasks(false,false,true);")
html = html.replace('if(this.authed && navigator.onLine)this.loadTasks();', "if(this.authed && navigator.onLine){this.view==='metrics'?this.refreshAcademy():this.loadTasks();}")
html = html.replace('if(!document.hidden && this.authed && navigator.onLine)this.loadTasks();', "if(!document.hidden && this.authed && navigator.onLine){this.view==='metrics'?this.refreshAcademy():this.loadTasks();}")
html = html.replace('this.restoreSnapshot(); await this.loadTasks();', "this.restoreSnapshot();this.restoreGc();this.restoreAcademy();if(this.view==='metrics')void this.refreshAcademy();await this.loadTasks();")
html = html.replace('this.authed=true;this.lf.password=\'\';', "this.authed=true;this.lf.password='';if(this.view==='metrics')void this.refreshAcademy();")
html = html.replace('this.authed=false;this.tasks=[];', 'this.academyData=null;this.academyError=\'\';this.academySourceId=null;this.authed=false;this.tasks=[];')
html = html.replace('this.gcReport=null;this.gcStatus=', 'this.academyData=null;this.academyError=\'\';this.academySourceId=null;this.gcReport=null;this.gcStatus=')
html = html.replace('<div class="bitem" :class="{on:view===n.id}" @click="view=n.id">', '<button type="button" class="bitem" :class="{on:view===n.id}" :aria-label="n.t" :aria-current="view===n.id?\'page\':null" @click="view=n.id">')
html = html.replace('<span x-text="n.t"></span></div></template>', '<span x-text="n.t"></span></button></template>')
html = html.replace('  async init(){', (ROOT/'pwa-state.js').read_text().replace('__APP_VERSION__',APP_VERSION)+'\n  async init(){\n    this.initAppUpdates();',1)
html = html.replace('title="Обновить"', 'title="Обновить данные" aria-label="Обновить данные"')
html = html.replace('</header>', '''</header>
    <div class="max-w-7xl mx-auto px-5 lg:px-8" style="display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:8px;font-size:11px;color:#607368">
      <span role="status" x-text="appUpdateAvailable ? 'Доступна новая версия панели' : 'Версия 04.09 · 4'"></span>
      <button type="button" @click="updateApplication()" style="min-height:44px;text-decoration:underline;color:#2B4A33;font-weight:600">Обновить приложение</button>
    </div>''',1)
from build_business import apply_business
html = apply_business(html, ROOT)
from build_visual import apply_visual
html = apply_visual(html, ROOT)
(SITE / 'index.html').write_text(html)
import json
manifest=json.loads((SITE/'manifest.json').read_text())
manifest.update(name='Управление · Garden Group',short_name='GG Управление',description='Задачи, финансы и метрики направлений Garden Group')
(SITE/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
sw = (ROOT/'sw-source.js').read_text().replace('__APP_VERSION__',APP_VERSION)
(SITE / 'sw.js').write_text(sw)
print('Prepared Timeweb PWA:', len(html.encode()), 'bytes')
