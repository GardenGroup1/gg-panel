  get taskSummary(){
    const tasks=this.scopedTasks.filter(t=>t.status!=='archive');
    const done=tasks.filter(t=>t.done).length;
    return {total:tasks.length,done,pct:tasks.length?Math.round(done/tasks.length*100):0};
  },
  get taskKpis(){return [
    {key:'overdue',label:'Просрочено',hint:'Требуют внимания',n:this.dueStats.overdue,tone:'rose',icon:'circle-alert'},
    {key:'today',label:'На сегодня',hint:'Срок — сегодня',n:this.dueStats.today,tone:'peach',icon:'calendar-days'},
    {key:'soon',label:'До трёх дней',hint:'Ближайшие сроки',n:this.dueStats.soon,tone:'sky',icon:'timer'},
    {key:'nodate',label:'Без дедлайна',hint:'Нужно назначить срок',n:this.dueStats.nodate,tone:'lilac',icon:'calendar-clock'}
  ];},
  get deadlineRing(){
    let offset=0;
    const stops=this.dueSegments.filter(s=>s.n>0).map(s=>{const start=offset;offset+=s.pct;return `${s.color} ${start}% ${offset}%`;});
    return stops.length?'conic-gradient('+stops.join(',')+')':'#e5e9e7';
  },
  directionStyle(d){const c=dirColor(d);return `--direction-ink:${c.text};--direction-main:${c.main};--direction-bg:${c.bg}`;},
  directionIcon(d){return ({'Академия':'graduation-cap','Питомник':'sprout','Бюро':'pencil-ruler','Бухгалтерия и Финансы':'wallet-cards','Fanatic Botanic':'flower-2','Книги и Альбомы':'book-open','Сообщество':'users','Конференция':'mic-2','Урбан-Туры':'map','ЛК Томск':'trees','ЛК Бали':'sun','ЛК и Питомник Тюмень':'landmark'})[d]||'leaf';},
  get financeChart(){
    const sourceRows=this.selectedBusiness?.months||[];
    const profitKey=this.f.direction==='Академия'?'ebitda':'netProfit';
    const valid=n=>typeof n==='number'&&Number.isFinite(n);
    const rows=sourceRows.filter(r=>valid(r.revenueGross)||valid(r[profitKey]));
    const max=Math.max(1,...rows.flatMap(r=>[r.revenueGross,r[profitKey]]).filter(valid).map(Math.abs));
    return {max,rows:rows.map(r=>({month:r.month,label:new Date(r.month+'-01T12:00:00Z').toLocaleDateString('ru-RU',{month:'short',timeZone:'UTC'}),revenue:r.revenueGross,profit:r[profitKey],bars:[{key:'revenue',value:r.revenueGross},{key:'profit',value:r[profitKey]}].map(b=>({...b,valid:valid(b.value),height:valid(b.value)?Math.abs(b.value)/max*100:0}))}))};
  },
