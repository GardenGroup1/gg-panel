import re

def apply_visual(html, root):
    def replace(old, new, count=1):
        nonlocal html
        if old not in html: raise ValueError('Visual anchor missing: '+old[:100])
        html=html.replace(old,new,count)
    replace("view:'overview', mode:'list'", "view:'today', mode:'list'")
    replace("nav:[{id:'overview',t:'Обзор',icon:'layout-dashboard'},{id:'tasks',t:'Задачи',icon:'list'},{id:'finance',t:'Финансы',icon:'wallet'},{id:'metrics',t:'Метрики',icon:'bar-chart-3'}]", "nav:[{id:'tasks',t:'Задачи',icon:'list-checks'},{id:'overview',t:'Обзор',icon:'layout-dashboard'},{id:'finance',t:'Финансы',icon:'wallet',beta:true},{id:'metrics',t:'Метрики',icon:'bar-chart-3',beta:true}]")
    replace('  businessData:null', (root/'visual-state.js').read_text()+'\n  businessData:null')
    replace('    this.initBusiness();', "    this.initBusiness();\n    ['businessData','f.direction'].forEach(k=>this.$watch(k,()=>this.$nextTick(()=>lucide.createIcons())));")
    replace('<span x-text="n.t"></span></button></template>','<span x-text="n.t"></span><small x-show="n.beta" class="nav-beta">Бета</small></button></template>')
    replace(':aria-label="n.t"', ':aria-label="n.t+(n.beta?\' · бета\':\'\')"')
    replace("'Версия 05.09 · Управление'", "'Версия 08.09 · Пульт 09'")
    replace('<header class="py-4">','<header class="py-4 app-header">')
    replace('<div class="max-w-7xl mx-auto px-5 lg:px-8" style="display:flex;flex-wrap:wrap;', '<div class="max-w-7xl mx-auto px-5 lg:px-8 app-update-strip" style="display:flex;flex-wrap:wrap;')
    replace('class="rounded-xl px-4 py-3 text-sm flex flex-wrap gap-2 items-center" :style="readOnly', 'class="rounded-xl px-4 py-3 text-sm flex flex-wrap gap-2 items-center connection-banner" :style="readOnly')
    replace('<span x-show="offlineReady && hasData && !cacheError">', '<span class="saved-device-label" x-show="offlineReady && hasData && !cacheError">')
    replace('<strong class="business-amount" x-text="academyMoney(m.value)">','<strong class="business-amount" :class="{negative:m.value<0}" x-text="academyMoney(m.value)">')
    replace('<div x-show="view===\'today\'" class="space-y-6">','<div x-show="view===\'today\'" class="space-y-6 task-home">')
    start=html.index('        <!-- Приветствие -->')
    end=html.index('        <!-- Ряд 3:',start)
    html=html[:start]+(root/'task-home.html').read_text()+'\n'+html[end:]
    # Give every working area a real screen identity while keeping all figures data-bound.
    replace('<section x-show="view===\'overview\'" class="academy business-overview"', '<section x-show="view===\'overview\'" class="academy business-overview overview-view"')
    replace('<section x-show="view===\'finance\'" class="academy"', '<section x-show="view===\'finance\'" class="academy finance-view"')
    replace('<section x-show="view===\'metrics\' && f.direction!==\'Академия\'" class="academy"', '<section x-show="view===\'metrics\' && f.direction!==\'Академия\'" class="academy metrics-view"')
    replace('<section x-show="view===\'metrics\' && f.direction===\'Академия\'" class="academy"', '<section x-show="view===\'metrics\' && f.direction===\'Академия\'" class="academy metrics-view academy-metrics-view"')
    replace('''<div x-show="view==='pulse'" class="space-y-6">
        <div class="pt-4">
          <div class="eyebrow">Обзор</div><h1 class="serif text-4xl mt-2">Пульс</h1>
          <div class="text-muted text-sm mt-2">Как живут 12 направлений и кто чем занят</div>
        </div>''','''<div x-show="view==='pulse'" class="space-y-6 workspace-view pulse-view">
        <header class="workspace-hero">
          <div class="workspace-hero-copy"><div class="workspace-kicker"><i data-lucide="activity"></i> Живой срез задач</div><h1>Пульс</h1><p>Как распределена работа между направлениями и людьми прямо сейчас.</p></div>
          <div class="workspace-hero-metrics"><div><strong x-text="stats.open"></strong><span>в работе</span></div><div><strong x-text="donut.length"></strong><span>направлений</span></div></div>
          <div class="workspace-orbits" aria-hidden="true"><i></i><i></i><i></i></div>
        </header>''')
    replace('''<div x-show="view==='tasks'" class="space-y-5">
        <div class="pt-4 flex flex-wrap items-end justify-between gap-3">
          <div>
            <div class="eyebrow">Все направления</div><h1 class="serif text-4xl mt-2">Задачи</h1>
            <div class="text-muted text-sm mt-1"><span x-text="filtered.length"></span> из <span x-text="tasks.length"></span></div>
          </div>''','''<div x-show="view==='tasks'" class="space-y-5 workspace-view tasks-view">
        <header class="workspace-hero task-list-hero">
          <div class="workspace-hero-copy"><div class="workspace-kicker"><i data-lucide="list-checks"></i> Рабочий контур</div><h1>Все задачи</h1><p><strong x-text="filtered.length"></strong> показано из <span x-text="tasks.length"></span> · фильтры и представления сохраняют реальные задачи.</p></div>
          <div class="workspace-hero-metrics"><div><strong x-text="stats.open"></strong><span>в работе</span></div><div><strong x-text="taskSummary.pct+'%'"></strong><span>закрыто</span></div></div>
          <div class="workspace-orbits" aria-hidden="true"><i></i><i></i><i></i></div>
        </header>
        <div class="task-view-toolbar flex flex-wrap items-end justify-between gap-3">
          <div class="task-view-caption"><span>Выберите удобный вид</span><small x-text="directionLabel"></small></div>''')
    replace('''<div x-show="view==='inbox'" class="space-y-5">
        <div class="pt-4"><div class="eyebrow">Новое</div><h1 class="serif text-4xl mt-2">Инбокс</h1><div class="text-muted text-sm mt-1">Поручения из Hermes. Здесь они хранятся, пока вы уточняете направление, срок и приоритет.</div></div>''','''<div x-show="view==='inbox'" class="space-y-5 workspace-view inbox-view">
        <header class="workspace-hero">
          <div class="workspace-hero-copy"><div class="workspace-kicker"><i data-lucide="inbox"></i> Входящий поток</div><h1>Инбокс</h1><p>Поручения из Hermes ждут проверки, направления и срока до отправки в рабочий список.</p></div>
          <div class="workspace-hero-metrics"><div><strong x-text="scopedInbox.length"></strong><span>на разборе</span></div><div><strong x-text="online?'LIVE':'OFF'"></strong><span x-text="online?'сервер на связи':'сохранённая копия'"></span></div></div>
          <div class="workspace-orbits" aria-hidden="true"><i></i><i></i><i></i></div>
        </header>''')
    replace('''<div x-show="view==='graveyard'" class="space-y-5">
        <div class="pt-4"><div class="eyebrow">Разобрать</div><h1 class="serif text-4xl mt-2">Архив</h1><div class="text-muted text-sm mt-1">Больше 30 дней без движения. Разберите раз в месяц.</div></div>''','''<div x-show="view==='graveyard'" class="space-y-5 workspace-view archive-view">
        <header class="workspace-hero">
          <div class="workspace-hero-copy"><div class="workspace-kicker"><i data-lucide="archive"></i> История и ревизия</div><h1>Архив</h1><p>Стагнация старше 30 дней и сохранённые задачи для регулярного разбора.</p></div>
          <div class="workspace-hero-metrics"><div><strong x-text="graveyard.length"></strong><span>без движения</span></div><div><strong x-text="archivedTasks.length"></strong><span>в архиве</span></div></div>
          <div class="workspace-orbits" aria-hidden="true"><i></i><i></i><i></i></div>
        </header>''')
    replace("const colors={XL:'#1F3A28',L:'#2B4A33',M:'#3A7D4A',S:'#5F9E5F',XS:'#9DB48C'};", "const colors={XL:'#716099',L:'#426d91',M:'#3f8065',S:'#b48344',XS:'#b35f7b'};")
    replace("{key:'today',label:'дедлайн сегодня',n:today,color:'#E89B26'}", "{key:'today',label:'дедлайн сегодня',n:today,color:'#b77925'}")
    replace("{key:'soon',label:'до трёх дней',n:soon,color:'#C9A83A'}", "{key:'soon',label:'до трёх дней',n:soon,color:'#426d91'}")
    replace('      <article x-show="selectedFinance.available && [\'summary\',\'pnl\'].includes(financeTab)"', (root/'finance-chart.html').read_text()+'\n      <article x-show="selectedFinance.available && [\'summary\',\'pnl\'].includes(financeTab)"')
    replace('<section x-show="!isTaskView" class="business-status">', '<section x-show="!isTaskView" class="business-status">\n<div x-show="view===\'finance\'||view===\'metrics\'" class="beta-notice"><span class="beta-symbol" aria-hidden="true"><i data-lucide="flask-conical"></i></span><div><strong>Бета-версия</strong><p>Подключаем источники. У каждого показателя указаны период и способ обновления.</p></div></div>')
    # Every direction keeps its existing color mapping throughout navigation and task lists.
    html=html.replace('class="card business-direction-card"', 'class="card business-direction-card" :style="directionStyle(d)"')
    html=html.replace('<span x-text="directionName(d)"></span><small', '<span class="tile-icon direction-icon" aria-hidden="true"><i :data-lucide="directionIcon(d)"></i></span><span x-text="directionName(d)"></span><small')
    replace('<div class="stitle">Направления</div>', '<div class="stitle"><span class="section-icon mint" aria-hidden="true"><i data-lucide="layers"></i></span>Направления</div>')
    replace('<div class="stitle">Сотрудники</div>', '<div class="stitle"><span class="section-icon lilac" aria-hidden="true"><i data-lucide="users"></i></span>Сотрудники</div>')
    replace('class="flex items-center gap-3 p-2 rounded-xl hover:bg-bg cursor-pointer" @click="view=\'tasks\';f.direction=d.name"', 'class="flex items-center gap-3 p-2 rounded-xl cursor-pointer task-direction-row" :style="directionStyle(d.name)" @click="view=\'tasks\';f.direction=d.name"')
    replace('class="flex items-center gap-3 p-2 rounded-xl hover:bg-bg cursor-pointer" @click="view=\'tasks\';f.owner=p.name"', 'class="flex items-center gap-3 p-2 rounded-xl cursor-pointer task-owner-row" @click="view=\'tasks\';f.owner=p.name"')
    replace('<span class="flex-1 text-[14px] font-medium" x-text="p.name"></span>', '<span class="owner-initial" aria-hidden="true" x-text="p.name.slice(0,1)"></span><span class="flex-1 text-[14px] font-medium" x-text="p.name"></span>')
    # Heading icons are functional category markers; all figures remain data-bound.
    html=re.sub(r'<h1>(Финансы|Метрики|Метрики Академии)</h1>',r'<h1>\1 <span class="heading-beta">Бета</span></h1>',html)
    replace('<nav class="bnav bnav-always">', '<nav class="bnav bnav-always"><div class="desktop-nav-brand"><b>GG</b><span>Garden Group<small>Пульт руководителя</small></span></div>')
    replace('</head>', '<style>'+(root/'visual.css').read_text()+'\n'+(root/'control-design.css').read_text()+'\n'+(root/'control-sections.css').read_text()+'\n'+(root/'signal-design.css').read_text()+'</style>\n</head>')
    replace('</body>', '<script>'+(root/'visual-motion.js').read_text()+'</script>\n</body>')
    return html
