  businessData:null,businessLoading:false,businessError:'',businessOffline:false,businessSourceId:null,
  callReport:null,callError:'',callOffline:false,inventoryReport:null,inventoryError:'',inventoryOffline:false,sourceRefreshing:false,
  financeMonth:'2026-08',financeTab:'summary',showSettings:false,lastTaskView:'today',
  taskTabs:[{id:'today',label:'Сегодня'},{id:'tasks',label:'Все задачи'},{id:'pulse',label:'Пульс задач'},{id:'inbox',label:'Инбокс'},{id:'graveyard',label:'Архив'}],
  financeTabs:[{id:'summary',label:'Сводка'},{id:'pnl',label:'Доходы и расходы'},{id:'cash',label:'Движение денег'},{id:'plan',label:'План / факт'},{id:'sources',label:'Источники'}],
  get isTaskView(){return this.taskTabs.some(t=>t.id===this.view);},
  get mainSection(){return this.isTaskView?'tasks':this.view;},
  get directionLabel(){return this.directionName(this.f.direction)||'Вся группа';},
  directionName(d){return d==='ЛК и Питомник Тюмень'?'Тюмень':d;},
  get businessDirections(){return ['Академия','Питомник','Бюро',...DIRS.filter(d=>!['Академия','Питомник','Бюро'].includes(d))];},
  get scopedTasks(){return this.tasks.filter(t=>!this.f.direction||t.direction===this.f.direction);},
  get scopedInbox(){return this.inbox.filter(t=>!this.f.direction||t.direction===this.f.direction);},
  get selectedBusiness(){return this.businessData?.directions[this.f.direction]||null;},
  get financeMonths(){return Array.from({length:9},(_,i)=>{const id='2026-'+String(i+1).padStart(2,'0'),date=new Date(id+'-01T12:00:00Z');return{id,label:this.monthLabel(id),short:date.toLocaleDateString('ru-RU',{month:'short',timeZone:'UTC'}).replace('.','')};});},
  monthLabel(m){if(!/^\d{4}-\d{2}$/.test(m||''))return 'Период не указан';return new Date(m+'-01T12:00:00Z').toLocaleDateString('ru-RU',{month:'long',year:'numeric',timeZone:'UTC'});},
  businessDate(d){if(!d)return 'нет даты';const dt=new Date(d);return Number.isFinite(+dt)?dt.toLocaleString('ru-RU',{dateStyle:'short',timeStyle:'short'}):d;},
  get financeRows(){const connected=['Академия','Бюро','Питомник','Сообщество','Книги и Альбомы','Конференция','ЛК и Питомник Тюмень'].filter(direction=>this.businessData?.directions?.[direction]);return (this.f.direction?[this.f.direction]:connected).map(direction=>{
    const d=this.businessData?.directions[direction],row=d?.months.find(r=>r.month===this.financeMonth);
    return {direction,label:this.directionName(direction),source:d?.source,row:row||{},available:!!row,latest:d?.months.at(-1)?.month,note:d?.note||'Финансовый источник ещё не подключён.',profitLabel:d?.profitLabel||'Прибыль',profit:direction==='Академия'?row?.ebitda:row?.netProfit};
  });},
  get selectedFinance(){return this.financeRows[0]||{row:{}};},
  get previousFinance(){const m=this.financeMonth.split('-').map(Number),dt=new Date(Date.UTC(m[0],m[1]-2,1)),key=dt.toISOString().slice(0,7);return this.selectedBusiness?.months.find(r=>r.month===key);},
  financeChange(key){const a=this.selectedFinance.row[key],b=this.previousFinance?.[key];if(a==null||b==null)return 'Нет сопоставимого предыдущего месяца';return (a-b>0?'+':'')+this.academyMoney(a-b)+' к предыдущему месяцу';},
  get financeIndicators(){const r=this.selectedFinance.row;return [
    {key:'revenueGross',label:'Выручка с НДС по таблице',value:r.revenueGross},
    {key:'revenueNet',label:'Выручка без НДС по таблице',value:r.revenueNet},
    {key:this.f.direction==='Академия'?'ebitda':'netProfit',label:this.selectedFinance.profitLabel,value:this.selectedFinance.profit},
    {key:'marketing',label:'Маркетинг по таблице',value:r.marketing},
    {key:'payroll',label:'Начисленный ФОТ',value:r.payroll},
    {key:'payrollToPay',label:'К выплате по зарплатной таблице',value:r.payrollToPay}].filter(item=>item.value!=null);},
  get financeDetails(){const labels={revenueGross:'Выручка с НДС',revenueNet:'Выручка без НДС',directCosts:'Прямые расходы',grossProfit:'Валовая прибыль',opex:'Операционные расходы',marketing:'В том числе маркетинг',payroll:'Начисленный ФОТ',payrollToPay:'К выплате по зарплатной таблице',ebitda:this.f.direction==='Питомник'?'Операционная прибыль (EBIT)':'EBITDA по таблице',tax:'Налоги',netProfit:'Чистая прибыль',inventory:'Инвентаризация на конец месяца'};return Object.entries(labels).map(([key,label])=>({key,label,value:this.selectedFinance.row[key]})).filter(item=>item.value!=null);},
  get visibleBusinessSources(){const ids=new Set([this.selectedBusiness?.source,...(this.selectedBusiness?.sources||[])]);return (this.businessData?.sources||[]).filter(s=>!this.f.direction||ids.has(s.id)||(this.f.direction==='Бюро'&&s.id==='bureau-contracts')||(this.f.direction==='Академия'&&['maxim','care'].includes(s.id)));},
  businessSource(id){return this.businessData?.sources.find(s=>s.id===id)||null;},
  get selectedBusinessSource(){return this.businessSource(this.businessSourceId);},
  sourceMode(s){return s?.mode==='monthly'?'Ежемесячный статичный отчёт':'Статичный срез таблицы';},
  get selectedReportBlocks(){return (this.businessData?.blocks||[]).filter(b=>b.direction===this.f.direction&&b.category===this.academyTab);},
  get visibleBusinessIssues(){return (this.businessData?.issues||[]).filter(i=>!this.f.direction||i.direction===this.f.direction);},
  get businessContractMonth(){return this.selectedBusiness?.contracts?.find(r=>r.month===this.financeMonth);},
  get filteredAcademyTabs(){return this.academyTabs.filter(t=>t.id!=='finance');},
  get callSubdivision(){if(!this.callReport)return null;if(!this.f.direction)return '__all__';return this.callReport.directionMap?.[this.f.direction]?.[0]||null;},
  get callDashboard(){const subdivision=this.callSubdivision;if(!subdivision)return null;return this.callReport?.months?.find(row=>row.period===this.financeMonth&&row.subdivision===subdivision)||null;},
  get callTrend(){const subdivision=this.callSubdivision;if(!subdivision)return [];const rows=(this.callReport?.days||[]).filter(row=>row.date?.startsWith(this.financeMonth)&&row.subdivision===subdivision);const max=Math.max(1,...rows.map(row=>row.calls||0));return rows.map(row=>({...row,height:Math.max(5,Math.round((row.calls||0)/max*100)),label:new Date(row.date+'T12:00:00Z').toLocaleDateString('ru-RU',{day:'numeric',timeZone:'UTC'})}));},
  get callQualityStages(){const row=this.callDashboard;if(!row)return [];return [{key:'scoreGreeting',label:'Приветствие'},{key:'scoreQualification',label:'Квалификация'},{key:'scorePresentation',label:'Презентация'},{key:'scoreObjections',label:'Возражения'},{key:'scoreClosing',label:'Завершение'}].map(item=>({...item,value:row[item.key]}));},
  callDuration(seconds){if(seconds==null)return '—';const total=Math.round(seconds/60),hours=Math.floor(total/60),minutes=total%60;return hours?hours+' ч '+minutes+' мин':minutes+' мин';},
  callNumber(value,digits=0){return value==null?'—':Number(value).toLocaleString('ru-RU',{minimumFractionDigits:digits,maximumFractionDigits:digits});},
  goMain(id){this.view=id==='tasks'?this.lastTaskView:id;this.showSettings=false;},
  goDirection(direction,section='overview'){this.f.direction=direction;this.view=section;this.showSettings=false;},
  businessHash(){if(typeof history==='undefined')return;const dir=this.f.direction?'/'+encodeURIComponent(this.f.direction):'';const tab=this.view==='metrics'&&this.f.direction==='Академия'?'/'+this.academyTab:'';history.replaceState(null,'','#'+this.view+dir+tab);},
  initBusiness(){
    const saved=storage.get(STORAGE_PREFIX+'direction');if(DIRS.includes(saved))this.f.direction=saved;
    let parts=[];try{parts=decodeURIComponent(location.hash.replace(/^#/,'' )).split('/');}catch{}
    const known=['overview','finance','metrics',...this.taskTabs.map(t=>t.id)];
    if(known.includes(parts[0]))this.view=parts[0];
    if(DIRS.includes(parts[1]))this.f.direction=parts[1];
    else if(parts[0]==='metrics'){this.f.direction='Академия';if(this.academyTabs.some(t=>t.id===parts[1]))this.academyTab=parts[1];}
    if(parts[0]==='metrics'&&this.academyTabs.some(t=>t.id===parts[2]))this.academyTab=parts[2];
    if(this.academyTab==='finance'){this.view='finance';this.academyTab='overview';}
    if(this.isTaskView)this.lastTaskView=this.view;
    this.restoreBusiness();
    this.$watch('f.direction',()=>{storage.set(STORAGE_PREFIX+'direction',this.f.direction);this.f.owner='';this.businessHash();});
    this.$watch('view',()=>{if(this.isTaskView)this.lastTaskView=this.view;this.businessHash();this.$nextTick(()=>window.scrollTo({top:0,behavior:'instant'}));if(this.authed&&!this.isTaskView)void this.refreshBusiness();});
    this.$watch('authed',v=>{if(v)void this.refreshBusiness();else this.clearBusiness();});
    window.addEventListener('gg-auth-expired',()=>this.clearBusiness());
    if(this.authed)void this.refreshBusiness();
  },
  restoreBusiness(){try{const d=JSON.parse(storage.get(STORAGE_PREFIX+'business')||'null');if(d?.schema===1&&d.directions&&Array.isArray(d.sources)){this.businessData=d;this.businessOffline=true;}const c=JSON.parse(storage.get(STORAGE_PREFIX+'calls')||'null');if(c?.schema===1&&Array.isArray(c.months)&&Array.isArray(c.days)){this.callReport=c;this.callOffline=true;}const i=JSON.parse(storage.get(STORAGE_PREFIX+'inventory')||'null');if(i?.schema===1&&i.totals&&Array.isArray(i.components)){this.inventoryReport=i;this.inventoryOffline=true;}}catch{}},
  clearBusiness(){this.businessData=null;this.businessSourceId=null;this.businessError='';this.callReport=null;this.callError='';this.callOffline=false;this.inventoryReport=null;this.inventoryError='';this.inventoryOffline=false;this.showSettings=false;storage.remove(STORAGE_PREFIX+'business');storage.remove(STORAGE_PREFIX+'calls');storage.remove(STORAGE_PREFIX+'inventory');},
  async loadBusiness(){
    if(!this.authed||this.businessLoading)return;
    if(!navigator.onLine){this.businessOffline=!!this.businessData;return;}
    this.businessLoading=true;this.businessError='';
    try{const r=await api('business_metrics');if(!this.authed)return;
      if(!r.ok){this.businessError=r.error||'Не удалось получить данные направлений';this.businessOffline=!!this.businessData;return;}
      if(r.report?.schema!==1||!r.report.directions||!Array.isArray(r.report.sources)){this.businessError='Формат отчётов изменился. Обновите приложение.';return;}
      this.businessData=r.report;this.businessOffline=false;
      if(r.calls?.ok&&r.calls.report?.schema===1){this.callReport=r.calls.report;this.callOffline=!!r.calls.stale;this.callError=r.calls.warning||'';storage.set(STORAGE_PREFIX+'calls',JSON.stringify(r.calls.report));}
      else if(r.calls){this.callError=r.calls.error||'Агрегаты звонков временно недоступны';this.callOffline=!!this.callReport;}
      if(r.inventory?.ok&&r.inventory.report?.schema===1){this.inventoryReport=r.inventory.report;this.inventoryOffline=!!r.inventory.stale;this.inventoryError=r.inventory.warning||'';storage.set(STORAGE_PREFIX+'inventory',JSON.stringify(r.inventory.report));}
      else if(r.inventory){this.inventoryError=r.inventory.error||'Актуальная инвентаризация временно недоступна';this.inventoryOffline=!!this.inventoryReport;}
      if(!storage.set(STORAGE_PREFIX+'business',JSON.stringify(r.report)))this.businessError='Данные загружены, но сохранить их на устройстве не удалось.';
    }finally{this.businessLoading=false;}
  },
  async refreshBusiness(){await Promise.all([this.loadBusiness(),this.refreshAcademy(),this.view==='overview'&&!this.loading?this.loadTasks(false,false,true):Promise.resolve()]);},
  async manualRefreshSources(){
    if(!this.authed||this.sourceRefreshing||!this.online)return;
    this.sourceRefreshing=true;
    try{
      const r=await api('business_refresh_sources');
      if(!r.ok){this.toast(r.error||'Не удалось обновить подключённые источники.');return;}
      await this.loadBusiness();
      const updated=[r.refreshed?.calls?'звонки':'',r.refreshed?.inventory?'инвентаризация':''].filter(Boolean).join(' и ');
      this.toast(updated?'Обновлены: '+updated:'Источники не подтвердили обновление. Показан сохранённый срез.');
    }finally{this.sourceRefreshing=false;}
  },
