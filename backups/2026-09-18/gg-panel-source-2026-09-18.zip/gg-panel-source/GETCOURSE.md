# GetCourse dashboard — 2026-09-04

Published at https://201.51.20.34/#metrics. **Updated: an existing configured key is working after the actual school export schema was repaired.** A real August snapshot has been loaded and compared with UI control totals. The existing two-hour refresh remains enabled; the first complete 90-day refresh is pending. See `ACADEMY.md` for current evidence and boundaries. The implementation notes below originated before live verification.

## Scope

- School: `gardenschool7`, custom host `https://garden-group.online` (observed in the account settings).
- Six cards: received payment amount, returned payment amount, average received payment, positive-cost orders, completed positive-cost orders, received payment count.
- Daily payment chart, order statuses, top 10 whole order compositions by order cost.
- Period presets 7 days / 30 days / current month; custom dates inside the downloaded 90-day window; separate currencies; previous equal-length period when available.
- UI never displays zero as a substitute for an unloaded report. Existing loaded reports survive refresh failures. The last displayed aggregate is saved locally for offline reading and cleared on logout / expired authentication.

## Server

`server.mjs` imports `getcourse.mjs` as well as the existing `capture.mjs`. All `gc_metrics`, `gc_refresh` and `gc_configure` actions are behind the existing panel authentication. No API key or user contacts are included in the public site or metrics response.

Private files, when configured:

- `/var/lib/gg-panel/getcourse-config.json`: secret key, account, default currency (0600).
- `/var/lib/gg-panel/getcourse-state.json`: normalized records without contact columns, atomic snapshot, queued export job, rolling request counter (0600).

Exports are sequential: payments first, deals second. Both must validate before replacing the report. Progress survives process restart. Background refresh is approximately every two hours; the module allows at most 20 of its own requests per rolling two-hour window, including polls. GetCourse's shared account limit may also be consumed by existing integrations. Browser polling reads the server snapshot without creating another export.

Only the fixed school HTTPS origin is allowed; API redirects are rejected to avoid forwarding the key to another origin. HTTP responses / errors never echo the key. Configuration can be corrected before the first successful report, provided a job is not in progress. Rotation after a successful connection is a server-admin operation.

## Calculation boundaries

Dates filter creation date, not payment acceptance date or refund processing date. Returned payments are records currently in the returned status that were created inside the selected dates. They must not be labeled as refunds processed during those dates.

Received totals exclude expected payments and internal/virtual payment types. Orders must have positive cost and cannot have the false status; cancelled orders remain part of the created-order cohort. Free completed registrations do not increase completed paid-order counts. Average payment is not average order. A multi-offer order remains a single composition; its price is not allocated arbitrarily among courses. Moscow calendar dates are used for relative period boundaries. Currency amounts are never added across currencies; missing currency columns currently use RUB.

**Pending live verification:** API export field names, payment type names, exact response shape, currency representation, account timezone and financial totals must be checked against real school exports after key approval. Unexpected formats stop synchronization and retain the last complete report. The first implementation is based on the public export contract plus strict field aliases, not on an observed live API response.

Sources: [GetCourse API](https://getcourse.ru/help/api), [API key generation](https://getcourse.ru/blog/1053682), [order statuses](https://getcourse.ru/blog/275983).

## Validation and deployment

- `verify.mjs`, `verify-capture.mjs`, `verify-getcourse.mjs` passed. Fixtures cover currency separation, received/internal/expected/returned payments, free/false/partial orders, date validation, duplicates, authenticated endpoints, atomic export, persistence across restart, refresh schedule, private output and offline UI.
- Live desktop and 390×844 Chrome layout checked. No console errors observed; no horizontal page overflow. The API returns the unconfigured state; dashboard shows dashes. Physical iPhone testing and real-data reconciliation remain pending.
- Live SHA-256 matched local files after deploy; services `gg-panel`, `zelenye-app` and `zelenye-cms` active.
- Pre-change backup: `/srv/gg-panel-backup-before-getcourse-20260904`. It excludes private state, which remains in `/var/lib/gg-panel`.
- Deployed files: `server.mjs`, `capture.mjs`, `getcourse.mjs`, `site/`, `deploy/`, `hermes/`. Existing state, HTTPS configuration and Hermes access key were preserved.
- PWA shell version `2026-09-04-getcourse-1`. Existing installations may require reload after the new service worker activates.

Do not claim that the integration is connected until a real export has completed and been checked. Do not publish either private state file or the original Apps Script `Api.gs`.
