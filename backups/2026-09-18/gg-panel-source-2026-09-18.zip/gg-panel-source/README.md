# Garden Group control panel source backup

Source snapshot of the Garden Group business and task panel deployed on Timeweb and embedded into the Tilda page `garden-group.pro/panel`.

Snapshot date: 2026-09-18.

Included: frontend/PWA, server gateway, build scripts, deploy configuration, Tilda wrapper, verification scripts and documentation.

Excluded intentionally: credentials, environment files, database dumps, GetCourse exports, financial/business JSON snapshots, employee reports, research downloads, virtual environments, `node_modules`, audio fixtures and release archives.

Runtime secrets belong only in protected server configuration.
