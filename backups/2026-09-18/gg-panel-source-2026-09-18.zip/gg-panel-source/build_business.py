import re

def apply_business(html, root):
    def replace(old,new,count=-1):
        nonlocal html
        if old not in html: raise ValueError('Business build anchor missing: '+old[:100])
        html=html.replace(old,new,count)
    replace('<title>Панель задач · Garden Group</title>','<title>Управление · Garden Group</title>')
    replace('content="GG Задачи"','content="GG Управление"')
    replace('<h1 class="serif text-3xl">Панель задач</h1>','<h1 class="serif text-3xl">Панель управления</h1>')
    replace("view:'today', mode:'list'", "view:'overview', mode:'list'")
    html=re.sub(r"  nav:\[.*?\],\n", "  nav:[{id:'overview',t:'Обзор',icon:'layout-dashboard'},{id:'tasks',t:'Задачи',icon:'list'},{id:'finance',t:'Финансы',icon:'wallet'},{id:'metrics',t:'Метрики',icon:'bar-chart-3'}],\n",html,count=1)
    replace('  async init(){', (root/'business-state.js').read_text()+'\n  async init(){\n    this.initBusiness();',1)
    # The new router also accepts old #metrics/products links and task hashes.
    old="    if(location.hash.startsWith('#metrics')){this.view='metrics';const tab=location.hash.split('/')[1];if(this.academyTabs.some(t=>t.id===tab))this.academyTab=tab;}\n    this.$watch('view',v=>{if(v==='metrics'){this.selectAcademyTab(this.academyTab);this.restoreAcademy();this.refreshAcademy();}else history.replaceState(null,'','#'+v);});\n"
    replace(old,'')
    replace("this.academyTab=id;history.replaceState(null,'','#metrics'+(id==='overview'?'':'/'+id));", "this.academyTab=id;this.businessHash();")
    replace("{id:'learning',label:'Обучение'}", "{id:'learning',label:'Обучение'},{id:'care',label:'Забота и сервис'}")
    replace('x-for="tab in academyTabs"','x-for="tab in filteredAcademyTabs"')
    replace("<section x-show=\"view==='metrics'\" class=\"academy\"", "<section x-show=\"view==='metrics' && f.direction==='Академия'\" class=\"academy\"")
    replace("view==='metrics' && academyTab==='connections'", "view==='metrics' && f.direction==='Академия' && academyTab==='connections'")
    replace('Отчёты проверены 04.09.2026','Новые отчёты добавлены 05.09.2026')
    replace('<template x-if="academyData"><div class="aa-panel">','<template x-if="academyData"><div class="aa-panel">\n'+(root/'business-report-blocks.html').read_text(),1)
    # Data loading is independent of the slower task endpoint.
    replace("hasData || view==='metrics'",'hasData || !isTaskView')
    replace("!hasData && view!=='metrics'",'!hasData && isTaskView')
    replace("hasData && loadError && view!=='metrics'",'hasData && loadError && isTaskView')
    replace("x-show=\"view!=='metrics'\"", 'x-show="isTaskView"')
    replace("x-show=\"view==='metrics'\" class=\"btn btn-ghost\" @click=\"logout()\"", 'x-show="!isTaskView" class="btn btn-ghost" @click="logout()"')
    replace("view==='metrics'?refreshAcademy():refresh()",'isTaskView?refresh():manualRefreshSources()')
    replace('title="Обновить данные" aria-label="Обновить данные"', ':title="isTaskView?\'Обновить задачи\':\'Обновить звонки и инвентаризацию\'" :aria-label="isTaskView?\'Обновить задачи\':\'Обновить звонки и инвентаризацию\'"')
    replace("this.view==='metrics'?this.refreshAcademy():this.loadTasks(false,false,true)","this.isTaskView?this.loadTasks(false,false,true):this.refreshBusiness()")
    replace("this.view==='metrics'?this.refreshAcademy():this.loadTasks()", "this.isTaskView?this.loadTasks():this.refreshBusiness()")
    html=html.replace("if(this.view==='metrics')this.refreshAcademy();", "if(!this.isTaskView)this.refreshBusiness();")
    replace("'academy_metrics','gc_metrics'", "'academy_metrics','business_metrics','gc_metrics'")
    replace('  logout(){\n', '  logout(){\n    this.clearBusiness();\n',1)
    replace("storage.remove(STORAGE_PREFIX+'academy');", "storage.remove(STORAGE_PREFIX+'academy');storage.remove(STORAGE_PREFIX+'business');")
    # Apply the common direction to every task view, without changing task storage/mutations.
    start=html.index('  // computed');end=html.index('  // actions',start)
    html=html[:start]+html[start:end].replace('this.tasks','this.scopedTasks')+html[end:]
    replace('const all=this.scopedTasks.filter(t=>t.direction===name);', "const all=this.scopedTasks.filter(t=>t.direction===name && t.status!=='archive');")
    replace('x-for="it in inbox"','x-for="it in scopedInbox"')
    html=html.replace('x-show="!inbox.length"','x-show="!scopedInbox.length"')
    replace(':class="{on:view===n.id}"',':class="{on:mainSection===n.id}"')
    replace(':aria-current="view===n.id?',':aria-current="mainSection===n.id?')
    replace('@click="view=n.id"','@click="goMain(n.id)"')
    # Insert the scope toolbar after the app-update strip, before task loading state.
    anchor='<section x-show="!hasData && isTaskView"'
    replace(anchor,(root/'business-controls.html').read_text()+'\n    '+anchor,1)
    anchor='      <!-- ===== СЕГОДНЯ ===== -->'
    business=(root/'business.html').read_text().replace('  <!-- CALL_METRICS -->',(root/'call-metrics.html').read_text()).replace('  <!-- INVENTORY_METRICS -->',(root/'inventory-metrics.html').read_text())
    replace(anchor,business+'\n'+anchor,1)
    replace('</head>','<style>'+(root/'business.css').read_text()+'</style>\n</head>',1)
    replace("'Версия 04.09 · 4'", "'Версия 05.09 · Управление'")
    html=html.replace('GetCourse · срез 04.09</button>','Статичный срез GetCourse · 04.09</button>')
    html=html.replace('Проверено в GetCourse · срез</button>','Статичный срез GetCourse</button>')
    return html
