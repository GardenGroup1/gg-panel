import http from 'node:http';
import { createHash, timingSafeEqual } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync, renameSync, existsSync } from 'node:fs';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createCapture } from './capture.mjs';
import { createGetCourse } from './getcourse.mjs';
import { createPostgresMetrics } from './postgres.mjs';
import { createInventoryMetrics } from './inventory.mjs';

const DEFAULT_UPSTREAM = 'https://script.google.com/macros/s/AKfycbw9B2sHf1qXwl08UrJrCB2G_QGbLrGi3QGP0qy9j3heQoGlfg9MspUKBXyPscoJ1rTcSQ/exec';
const hash = token => createHash('sha256').update(token).digest('hex');
const fail = (error, code = 'upstream') => ({ ok: false, code, error });
const DIRECTIONS = ['Бюро','Академия','Питомник','Бухгалтерия и Финансы','Fanatic Botanic','Книги и Альбомы','Сообщество','Конференция','Урбан-Туры','ЛК Томск','ЛК Бали','ЛК и Питомник Тюмень'];
const FIELDS = ['block','task','owner','deadline','size','prio'];

export function createPanel({ dataDir, fetchImpl = fetch, getCourseFetch = fetch, inventoryFetch = fetch, upstream = DEFAULT_UPSTREAM, now = Date.now, interval = 60000, startTimer = true, hermesKey = '', postgresEnv = process.env, PostgresPool } = {}) {
  mkdirSync(dataDir, { recursive: true, mode: 0o700 });
  // Owner decision: calls and inventory stay frozen until an explicit manual refresh.
  const metricsAutoRefresh=false;
  const getcourse = createGetCourse({dataDir, fetchImpl:getCourseFetch, now, startTimer});
  const postgres = createPostgresMetrics({env:postgresEnv,PoolImpl:PostgresPool,now,startTimer:metricsAutoRefresh,dataDir});
  const inventory = createInventoryMetrics({env:postgresEnv,fetchImpl:inventoryFetch,now,startTimer:metricsAutoRefresh,dataDir});
  // Financial snapshots stay outside the public site and use the existing session check.
  let academyReport=null;
  try { academyReport=JSON.parse(readFileSync(new URL('./academy-data.json',import.meta.url),'utf8')); }
  catch { /* Missing snapshot must never look like zero-valued metrics. */ }
  let businessReport=null;
  try { businessReport=JSON.parse(readFileSync(new URL('./business-data.json',import.meta.url),'utf8')); }
  catch { /* An absent business report is not a zero report. */ }
  const stateFile = join(dataDir, 'state.json');
  let state = { sessions: {}, syncToken: '', snapshot: null };
  if (existsSync(stateFile)) state = JSON.parse(readFileSync(stateFile, 'utf8'));
  let refreshing = null, writing = false, revision = 0, lastError = '', timer;
  const attempts = new Map();
  function persist() {
    for (const [k, v] of Object.entries(state.sessions)) if (v.exp <= now()) delete state.sessions[k];
    writeFileSync(stateFile + '.tmp', JSON.stringify(state), { mode: 0o600 });
    renameSync(stateFile + '.tmp', stateFile);
  }
  function valid(token) { return typeof token === 'string' && token.length <= 200 && state.sessions[hash(token)]?.exp > now(); }
  function revokeAll() { state.sessions = {}; state.syncToken = ''; persist(); }
  async function upstreamCall(body) {
    try {
      const res = await fetchImpl(upstream, { method: 'POST', redirect: 'follow', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify(body), signal: AbortSignal.timeout(105000) });
      if (!res.ok) return fail('Google временно недоступен. Сохранённые задачи остаются на сервере.');
      const result = await res.json();
      if (typeof result.ok !== 'boolean') return fail('Google вернул неверный ответ.');
      if (!result.ok && result.code === 'auth') return fail('Войдите ещё раз: доступ к Google истёк или был отозван.', 'auth');
      return result;
    } catch { return fail('Не удалось получить подтверждение от Google. Обновите задачи перед повтором.', 'network'); }
  }
  function validateSnapshot(r) {
    if (!Array.isArray(r.tasks) || r.count !== r.tasks.length || r.tasks.length > 50000) throw Error('Неполный ответ Google. Сохранена предыдущая копия.');
    const ids = new Set();
    for (const task of r.tasks) {
      if (!task || typeof task.id !== 'string' || !DIRECTIONS.includes(task.direction) || !task.id.startsWith(task.direction + '__') || typeof task.task !== 'string' || !task.task.trim() || ids.has(task.id)) throw Error('В ответе Google обнаружена ошибка. Сохранена предыдущая копия.');
      ids.add(task.id);
    }
    // The old Apps Script hides sheet-level errors. Do not silently erase an entire direction.
    const before = new Set(state.snapshot?.tasks.map(t => t.direction) || []);
    const after = new Set(r.tasks.map(t => t.direction));
    if ([...before].some(d => !after.has(d))) throw Error('Google не вернул задачи одного из направлений. Сохранена предыдущая копия; проверяем повторно.');
  }
  function refresh() {
    if (refreshing) return refreshing;
    if (!valid(state.syncToken) || writing) return Promise.resolve(false);
    const token = state.syncToken, startedRevision = revision;
    refreshing = (async () => {
      const r = await upstreamCall({ action: 'list', token });
      if (!valid(token)) return false;
      if (!r.ok) {
        lastError = r.error;
        if (r.code === 'auth') revokeAll();
        return false;
      }
      if (startedRevision !== revision || writing) return false;
      try { validateSnapshot(r); } catch (e) { lastError = e.message; return false; }
      state.snapshot = { tasks: r.tasks, at: new Date(now()).toISOString(), sourceAt: r.at || null };
      lastError = ''; persist(); return true;
    })().finally(() => { refreshing = null; });
    return refreshing;
  }
  function snapshotReply() {
    if (!state.snapshot) return fail(lastError || 'Сервер получает задачи из Google. Данные появятся автоматически.', 'warming');
    return { ok: true, tasks: state.snapshot.tasks, inbox: captures.list(), count: state.snapshot.tasks.length, at: state.snapshot.at,
      cached: true, syncing: !!refreshing, readOnly: writing || !!lastError || now() - Date.parse(state.snapshot.at) > 300000,
      warning: lastError, source: 'timeweb' };
  }
  function checkFields(body, create = false) {
    const out = {};
    for (const k of FIELDS) if (body[k] !== undefined) {
      if (typeof body[k] !== 'string' || body[k].length > (k === 'task' ? 10000 : 500)) throw Error('Проверьте заполнение полей задачи.');
      out[k] = body[k];
    }
    if ((create || 'task' in out) && !out.task?.trim()) throw Error('Введите название задачи.');
    if ('size' in out && !['XS','S','M','L','XL'].includes(out.size)) throw Error('Неверная крупность задачи.');
    if ('prio' in out && !['A','B','C','D'].includes(out.prio)) throw Error('Неверный приоритет.');
    if ('status' in body) {
      if (!['open','done','archive'].includes(body.status)) throw Error('Неверный статус.');
      out.status = body.status;
    } else if ('done' in body) {
      if (typeof body.done !== 'boolean') throw Error('Неверный статус.');
      out.status = body.done ? 'done' : 'open';
    }
    return out;
  }
  async function action(body, ip = 'local') {
    if (!body || typeof body !== 'object' || Array.isArray(body)) return fail('Неверный запрос.', 'input');
    if (body.action === 'health') return { ok: true, service: 'gg-panel', version: 'timeweb-1' };
    if (body.action === 'login') {
      const previous = attempts.get(ip);
      const a = previous?.until > now() ? previous : { count: 0, until: now() + 60000 };
      if (a.count >= 8) return fail('Слишком много попыток. Подождите минуту.', 'rate');
      a.count++; attempts.set(ip, a);
      if (attempts.size > 5000) for (const [key, value] of attempts) if (value.until <= now()) attempts.delete(key);
      if (typeof body.password !== 'string' || !body.password || body.password.length > 512) return fail('Введите пароль.', 'input');
      const r = await upstreamCall({ action: 'login', password: body.password });
      if (!r.ok) return r.code === 'auth' ? fail('Неверный пароль.', 'auth') : r;
      if (typeof r.token !== 'string' || r.token.length > 200 || !r.token) return fail('Сервер входа вернул неверный ответ.');
      const ttl = Math.min(Number(r.ttl) || 86400000, 30 * 86400000);
      state.sessions[hash(r.token)] = { exp: now() + ttl - 5000 };
      state.syncToken = r.token; persist(); attempts.delete(ip);
      void refresh();
      return { ok: true, token: r.token, ttl, user: r.user };
    }
    if (!valid(body.token)) return fail('Войдите в панель.', 'auth');
    if (body.action==='business_refresh_sources') {
      const [calls,stock]=await Promise.all([postgres.refresh(),inventory.refresh()]);
      return businessReport?.schema===1
        ? {ok:true,report:businessReport,calls:postgres.snapshotReply(),inventory:inventory.snapshotReply(),refreshed:{calls,inventory:stock}}
        : fail('Данные направлений пока не загружены.', 'unavailable');
    }
    if (body.action==='business_metrics') return businessReport?.schema===1
      ? {ok:true,report:businessReport,calls:postgres.snapshotReply(),inventory:inventory.snapshotReply()}
      : fail('Данные направлений пока не загружены.', 'unavailable');
    if (body.action==='academy_metrics') return academyReport?.schema===1
      ? {ok:true,report:{...academyReport,liveGetcourse:await getcourse.action({action:'gc_metrics',from:academyReport.period.from,to:academyReport.period.to,currency:'RUB'})}}
      : fail('Сохранённые метрики ещё не загружены на сервер.', 'unavailable');
    if (['gc_metrics','gc_refresh','gc_configure'].includes(body.action)) return getcourse.action(body);
    if (['inbox_accept','inbox_dismiss','inbox_restore'].includes(body.action)) return captures.userAction(body);
    if (body.action === 'logout') {
      delete state.sessions[hash(body.token)];
      if (state.syncToken === body.token) state.syncToken = '';
      persist(); void upstreamCall({ action: 'logout', token: body.token });
      return { ok: true };
    }
    if (!state.syncToken) { state.syncToken = body.token; persist(); void refresh(); }
    if (body.action === 'me') return { ok: true, user: { name: 'admin', role: 'admin' } };
    if (body.action === 'list') return snapshotReply();
    if (body.action === 'refresh') { void refresh(); return snapshotReply(); }
    if (!['create','update','archive','restore'].includes(body.action)) return fail('Неизвестное действие.', 'input');
    if (writing) return fail('Сохраняется предыдущее изменение. Подождите.', 'busy');
    if (!state.snapshot || snapshotReply().readOnly) return fail('Сначала дождитесь обновления задач. Пока доступно только чтение.', 'stale');
    let outgoing, patch, existing;
    try {
      if (body.action === 'create') {
        if (!DIRECTIONS.includes(body.direction)) throw Error('Выберите направление.');
        patch = checkFields(body, true);
        outgoing = { action: 'create', direction: body.direction, ...patch, token: body.token };
      } else {
        existing = state.snapshot.tasks.find(t => t.id === body.id);
        if (!existing) return fail('Задача больше не найдена. Обновите список.', 'conflict');
        patch = body.action === 'archive' ? { status: 'archive' } : body.action === 'restore' ? { status: 'open' } : checkFields(body.patch || {});
        if (body.expectedTask && body.expectedTask !== existing.task) return fail('Задача уже изменилась. Обновите список.', 'conflict');
        outgoing = { action: 'update', id: existing.id, patch, expectedTask: existing.task, token: body.token };
      }
    } catch (e) { return fail(e.message, 'input'); }
    writing = true; revision++;
    try {
      const r = await upstreamCall(outgoing);
      if (!r.ok) {
        if (r.code === 'auth') revokeAll();
        if (['network','upstream','conflict'].includes(r.code)) { lastError = 'Изменение требует проверки. Получаем актуальные данные из Google.'; }
        return r;
      }
      if (body.action === 'create') {
        if (typeof r.id !== 'string') { lastError = 'Создание требует проверки в Google.'; return fail(lastError); }
        state.snapshot.tasks.push({ id: r.id, direction: body.direction, block: '—', owner: '', deadline: '', size: 'M', prio: 'C', ...patch, status: 'open', done: false });
      } else {
        Object.assign(existing, patch);
        existing.done = existing.status === 'done';
      }
      persist(); return { ok: true, id: r.id || existing?.id };
    } finally {
      writing = false; revision++;
      // A concurrent pre-write read must finish and be discarded before reading again.
      const prior = refreshing;
      void Promise.resolve(prior).then(() => refresh());
    }
  }
  const captures = createCapture({ state, persist, now, directions: DIRECTIONS, normalize: checkFields,
    createTask: (body, token) => action({ ...body, action: 'create', token: token || state.syncToken }) });
  async function hermesAction(body) {
    if (body.action === 'context') return { ok: true, directions: DIRECTIONS,
      owners: [...new Set((state.snapshot?.tasks || []).map(t => t.owner).filter(Boolean))].sort(),
      today: new Intl.DateTimeFormat('sv-SE', { timeZone: 'Asia/Makassar', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date(now())),
      timezone: 'Asia/Makassar', defaultDirection: '', missingDirection: 'ask_owner', captureMode: 'draft_then_clarify', panelUrl: 'https://201.51.20.34/' };
    if (body.action === 'capture') return captures.capture(body);
    if (body.action === 'status') return captures.status(body.requestId);
    if (['draft_get','draft_update','draft_accept'].includes(body.action)) return captures.draftAction(body);
    if (body.action === 'drafts') return { ok: true, inbox: captures.list() };
    return fail('Неизвестное действие.', 'input');
  }
  const server = http.createServer(async (req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    const respond = (data, status = 200) => { res.writeHead(status, { 'Content-Type': 'application/json;charset=utf-8' }); res.end(JSON.stringify(data)); };
    if (req.url === '/health' && req.method === 'GET') return respond({ ok: true, service: 'gg-panel' });
    const internal = req.url === '/internal/hermes';
    if ((!internal && req.url !== '/api') || req.method !== 'POST') return respond(fail('Not found'), 404);
    if (internal) {
      const key = req.headers['x-gg-hermes-key'];
      if (!hermesKey || typeof key !== 'string' || Buffer.byteLength(key) !== Buffer.byteLength(hermesKey) || !timingSafeEqual(Buffer.from(key), Buffer.from(hermesKey))) return respond(fail('Forbidden', 'auth'), 403);
    }
    const chunks = []; let size = 0;
    try {
      for await (const chunk of req) {
        size += chunk.length;
        if (size > (internal ? 100000 : 32768)) return respond(fail('Запрос слишком большой.', 'input'), 413);
        chunks.push(chunk);
      }
      const body = JSON.parse(Buffer.concat(chunks).toString('utf8'));
      respond(internal ? await hermesAction(body) : await action(body, req.headers['x-real-ip'] || req.socket.remoteAddress));
    } catch { respond(fail('Не удалось обработать запрос. Попробуйте обновить страницу.'), 500); }
  });
  if (startTimer) { timer = setInterval(() => { void refresh(); }, interval); timer.unref(); void refresh(); }
  return { server, action, hermesAction, refresh, snapshotReply, close() { clearInterval(timer); getcourse.close(); postgres.close(); inventory.close(); server.close(); } };
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const keyFile = process.env.HERMES_KEY_FILE || '/etc/gg-panel-hermes.key';
  const app = createPanel({ dataDir: process.env.DATA_DIR || '/var/lib/gg-panel', hermesKey: existsSync(keyFile) ? readFileSync(keyFile, 'utf8').trim() : '' });
  app.server.listen(Number(process.env.PORT || 3012), '127.0.0.1', () => console.log('GG panel API ready on localhost'));
}
