#!/usr/bin/env bash
set -Eeuo pipefail

release=/tmp/gg-panel-control-5.tar.gz
secret=/tmp/gg-panel-postgres.env
stage=/tmp/gg-panel-control-5
expected_current=6d6f8e0a299de4c86f66279e6c7f5b7ce80b0737cd56f5c75912758979756c2d

test "$(sha256sum /srv/gg-panel/site/index.html | cut -d' ' -f1)" = "$expected_current"
test -f "$release"
test -f "$secret"
rm -rf "$stage"
tar -xzf "$release" -C /tmp
grep -q '2026-09-05-control-5' "$stage/site/index.html"
grep -q '2026-09-05-control-5' "$stage/site/sw.js"
grep -q 'Звонки и качество коммуникации' "$stage/site/index.html"
node --check "$stage/server.mjs"
node --check "$stage/postgres.mjs"

cd "$stage"
npm ci --omit=dev --ignore-scripts --no-audit --no-fund

set -a
. "$secret"
set +a
node --input-type=module -e "import('./postgres.mjs').then(async ({createPostgresMetrics})=>{const m=createPostgresMetrics({startTimer:false});const ok=await m.refresh();const r=m.snapshotReply();if(!ok||!r.ok||!r.report?.range?.rows)process.exit(1);console.log(JSON.stringify({postgres:true,rows:r.report.range.rows,through:r.report.range.through}));m.close()})"

stamp=$(date -u +%Y%m%dT%H%M%SZ)
backup=/srv/gg-panel-backups/postgres-$stamp
mkdir -p "$backup/site"
cp -a /srv/gg-panel/site/index.html /srv/gg-panel/site/sw.js "$backup/site/"
for file in server.mjs postgres.mjs package.json package-lock.json; do
  if test -e "/srv/gg-panel/$file"; then cp -a "/srv/gg-panel/$file" "$backup/"; fi
done
cp -a /etc/systemd/system/gg-panel.service "$backup/"

install -o root -g root -m 0644 "$stage/site/index.html" /srv/gg-panel/site/index.html
install -o root -g root -m 0644 "$stage/site/sw.js" /srv/gg-panel/site/sw.js
install -o root -g root -m 0644 "$stage/server.mjs" /srv/gg-panel/server.mjs
install -o root -g root -m 0644 "$stage/postgres.mjs" /srv/gg-panel/postgres.mjs
install -o root -g root -m 0644 "$stage/package.json" /srv/gg-panel/package.json
install -o root -g root -m 0644 "$stage/package-lock.json" /srv/gg-panel/package-lock.json
cp -a "$stage/node_modules" /srv/gg-panel/
chown -R root:root /srv/gg-panel/node_modules
install -o root -g gg-panel -m 0640 "$secret" /etc/gg-panel-postgres.env
install -o root -g root -m 0644 "$stage/deploy/gg-panel.service" /etc/systemd/system/gg-panel.service

systemctl daemon-reload
systemctl restart gg-panel.service
for _ in {1..15}; do
  if curl -fsS http://127.0.0.1:3012/health >/dev/null; then break; fi
  sleep 1
done
systemctl is-active --quiet gg-panel.service
curl -fsS http://127.0.0.1:3012/health
sha256sum /srv/gg-panel/site/index.html /srv/gg-panel/site/sw.js
echo "BACKUP=$backup"
rm -f "$secret" "$release"
