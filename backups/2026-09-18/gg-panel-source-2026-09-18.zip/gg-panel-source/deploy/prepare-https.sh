#!/bin/sh
set -eu
install -d -m 755 /var/www/gg-panel-acme
cat > /etc/nginx/sites-available/gg-panel <<'NGINX'
server {
  listen 80;
  server_name 201.51.20.34;
  location /.well-known/acme-challenge/ { root /var/www/gg-panel-acme; }
  location / { return 503; }
}
NGINX
ln -sfn /etc/nginx/sites-available/gg-panel /etc/nginx/sites-enabled/gg-panel
nginx -t
systemctl reload nginx
python3 -m venv /opt/gg-panel-certbot
/opt/gg-panel-certbot/bin/pip --disable-pip-version-check install --quiet 'certbot>=5.4,<6'
/opt/gg-panel-certbot/bin/certbot certonly --non-interactive --agree-tos --register-unsafely-without-email \
  --config-dir /etc/gg-panel-letsencrypt --work-dir /var/lib/gg-panel-letsencrypt --logs-dir /var/log/gg-panel-letsencrypt \
  --preferred-profile shortlived --webroot --webroot-path /var/www/gg-panel-acme --ip-address 201.51.20.34 \
  --cert-name gg-panel-ip --deploy-hook 'systemctl reload nginx'
