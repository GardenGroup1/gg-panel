#!/usr/bin/env bash
set -Eeuo pipefail

release=/tmp/gg-panel-control-7.tar.gz
stage=/tmp/gg-panel-control-7
expected_current=cd4603e410d1f7ef491f49bebe4c42b47a3e8ad9b522e123163c19361d7b737f

test "$(sha256sum /srv/gg-panel/site/index.html | cut -d' ' -f1)" = "$expected_current"
test -f "$release"
rm -rf "$stage"
mkdir -p "$stage"
tar -xzf "$release" -C "$stage"
grep -q '2026-09-05-control-7' "$stage/site/index.html"
grep -q '2026-09-05-control-7' "$stage/site/sw.js"
grep -q 'business-direction-picker' "$stage/site/index.html"
grep -q 'Компании и направления' "$stage/site/index.html"
if grep -q 'x-model="f.direction" aria-label="Направление"' "$stage/site/index.html"; then exit 1; fi

stamp=$(date -u +%Y%m%dT%H%M%SZ)
backup=/srv/gg-panel-backups/company-buttons-$stamp
mkdir -p "$backup/site"
cp -a /srv/gg-panel/site/index.html /srv/gg-panel/site/sw.js "$backup/site/"

install -o root -g root -m 0644 "$stage/site/index.html" /srv/gg-panel/site/index.html
install -o root -g root -m 0644 "$stage/site/sw.js" /srv/gg-panel/site/sw.js

systemctl restart gg-panel.service
for _ in {1..15}; do
  if curl -fsS http://127.0.0.1:3012/health >/dev/null; then break; fi
  sleep 1
done
systemctl is-active --quiet gg-panel.service
curl -fsS http://127.0.0.1:3012/health
sha256sum /srv/gg-panel/site/index.html /srv/gg-panel/site/sw.js
echo "BACKUP=$backup"
rm -f "$release"
