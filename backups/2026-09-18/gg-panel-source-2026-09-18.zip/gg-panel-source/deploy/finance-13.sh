#!/usr/bin/env bash
set -Eeuo pipefail

release=/tmp/gg-panel-finance-13.tar.gz
stage=/tmp/gg-panel-finance-13
expected_index=875ade473339540727abd33e54e980c36ebbeb931f715c07f4b3fdfe9fa7c78e
expected_sw=64881acc5ba41057975f5f4ff14dea535059472c322f6eabcb7cfe2788be29d6
expected_data=c771de45054bc084afa1d9f0e2ba8d84efffc99e7559b781721aeecd810b6999

test "$(sha256sum /srv/gg-panel/site/index.html | cut -d' ' -f1)" = "$expected_index"
test "$(sha256sum /srv/gg-panel/site/sw.js | cut -d' ' -f1)" = "$expected_sw"
test "$(sha256sum /srv/gg-panel/business-data.json | cut -d' ' -f1)" = "$expected_data"
test -f "$release"
rm -rf "$stage"
mkdir -p "$stage"
tar -xzf "$release" -C "$stage"
grep -q '2026-09-08-finance-13' "$stage/index.html"
grep -q '2026-09-08-finance-13' "$stage/sw.js"
grep -q 'Начисленный ФОТ' "$stage/index.html"
python3 - "$stage/business-data.json" <<'PY'
import json,sys
d=json.load(open(sys.argv[1]))
assert d['schema']==1
assert d['directions']['Сообщество']['months'][-1]['revenueGross']==103300
assert d['directions']['Сообщество']['months'][-1]['payroll']==90000
assert d['directions']['Книги и Альбомы']['months'][-1]['payroll']==60000
assert any(s['id']=='community-finance' for s in d['sources'])
assert any(s['id']=='academy-payroll' for s in d['sources'])
PY

stamp=$(date -u +%Y%m%dT%H%M%SZ)
backup=/srv/gg-panel-backups/finance-$stamp
mkdir -p "$backup/site"
cp -a /srv/gg-panel/site/index.html /srv/gg-panel/site/sw.js "$backup/site/"
cp -a /srv/gg-panel/business-data.json "$backup/"

rollback() {
  cp -a "$backup/site/index.html" /srv/gg-panel/site/index.html
  cp -a "$backup/site/sw.js" /srv/gg-panel/site/sw.js
  cp -a "$backup/business-data.json" /srv/gg-panel/business-data.json
  systemctl restart gg-panel.service
  echo "Release failed; restored $backup"
}
trap rollback ERR

install -o root -g gg-panel -m 0640 "$stage/business-data.json" /srv/gg-panel/business-data.json
install -o root -g root -m 0644 "$stage/index.html" /srv/gg-panel/site/index.html
install -o root -g root -m 0644 "$stage/sw.js" /srv/gg-panel/site/sw.js
systemctl restart gg-panel.service
for _ in {1..15}; do
  if curl -fsS http://127.0.0.1:3012/health > "$stage/health.json"; then break; fi
  sleep 1
done
systemctl is-active --quiet gg-panel.service
python3 -c 'import json,sys; assert json.load(open(sys.argv[1]))["ok"]' "$stage/health.json"
curl -fsS --max-time 10 --resolve 201.51.20.34:443:127.0.0.1 https://201.51.20.34/ > "$stage/served.html"
cmp "$stage/served.html" /srv/gg-panel/site/index.html
curl -fsS --max-time 10 -H 'Content-Type: application/json' --data '{"action":"business_metrics"}' http://127.0.0.1:3012/api > "$stage/auth.json"
python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); assert d["code"]=="auth" and "report" not in d' "$stage/auth.json"
sha256sum /srv/gg-panel/site/index.html /srv/gg-panel/site/sw.js /srv/gg-panel/business-data.json
echo "BACKUP=$backup"
trap - ERR
