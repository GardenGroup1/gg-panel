#!/bin/bash
set -euo pipefail
target=/srv/gg-panel/site
stamp=$(date -u +%Y%m%dT%H%M%SZ)
backup=/srv/gg-panel-backups/visual-$stamp
stage=/srv/gg-panel-visual-$stamp
test "$(sha256sum "$target/index.html" | cut -d' ' -f1)" = "2e03cabbe10fd4b5d48de4bc3258a81fe32c17283383598ead34c351f2ca36eb"
install -d -m 0700 "$backup" "$stage"
tar -xzf /tmp/gg-visual-20260905-color1.tar.gz -C "$stage"
test -f "$stage/index.html"
node --check "$stage/sw.js"
python3 -c 'from pathlib import Path; import sys; p=Path(sys.argv[1]); s=(p/"index.html").read_text(); assert "2026-09-05-color-1" in s and "task-hero" in s and "finance-chart" in s; assert "2026-09-05-color-1" in (p/"sw.js").read_text()' "$stage"
cp -p "$target/index.html" "$target/sw.js" "$backup/"
rollback() {
  cp -p "$backup/index.html" "$target/index.html"
  cp -p "$backup/sw.js" "$target/sw.js"
  printf 'Previous appearance restored from %s\n' "$backup"
}
trap rollback ERR
install -m 0644 -o root -g root "$stage/index.html" "$target/.index-visual-next"
mv "$target/.index-visual-next" "$target/index.html"
install -m 0644 -o root -g root "$stage/sw.js" "$target/.sw-visual-next"
mv "$target/.sw-visual-next" "$target/sw.js"
curl -fsS --max-time 10 http://127.0.0.1:3012/health > "$stage/health.json"
python3 -c 'import json,sys; assert json.load(open(sys.argv[1]))["ok"]' "$stage/health.json"
curl -fsS --max-time 10 --resolve 201.51.20.34:443:127.0.0.1 https://201.51.20.34/ > "$stage/served.html"
cmp "$stage/served.html" "$target/index.html"
sha256sum "$target/index.html" "$target/sw.js"
systemctl is-active gg-panel
printf 'BACKUP=%s\n' "$backup"
trap - ERR
