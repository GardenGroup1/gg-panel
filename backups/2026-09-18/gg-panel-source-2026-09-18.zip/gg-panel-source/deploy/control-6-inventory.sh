#!/usr/bin/env bash
set -Eeuo pipefail

release=/tmp/gg-panel-control-6.tar.gz
stage=/tmp/gg-panel-control-6
expected_current=a1fefccf41df939552a2413edf1c0d3c65eb52c8baefaaead3fb05e18baf7b58

test "$(sha256sum /srv/gg-panel/site/index.html | cut -d' ' -f1)" = "$expected_current"
test -f "$release"
rm -rf "$stage"
tar -xzf "$release" -C /tmp
grep -q '2026-09-05-control-6' "$stage/site/index.html"
grep -q '2026-09-05-control-6' "$stage/site/sw.js"
grep -q 'Живой остаток Питомника' "$stage/site/index.html"
node --check "$stage/server.mjs"
node --check "$stage/inventory.mjs"

cd "$stage"
node --input-type=module -e "import('./inventory.mjs').then(async ({createInventoryMetrics})=>{const m=createInventoryMetrics({startTimer:false});const ok=await m.refresh();const r=m.snapshotReply();if(!ok||!r.ok||r.report?.totals?.plants!==82572||r.report?.totals?.value!==34106610)process.exit(1);console.log(JSON.stringify({inventory:true,plants:r.report.totals.plants,value:r.report.totals.value}));m.close()})"

stamp=$(date -u +%Y%m%dT%H%M%SZ)
backup=/srv/gg-panel-backups/inventory-$stamp
mkdir -p "$backup/site"
cp -a /srv/gg-panel/site/index.html /srv/gg-panel/site/sw.js "$backup/site/"
cp -a /srv/gg-panel/server.mjs "$backup/"
if test -e /srv/gg-panel/inventory.mjs; then cp -a /srv/gg-panel/inventory.mjs "$backup/"; fi

install -o root -g root -m 0644 "$stage/site/index.html" /srv/gg-panel/site/index.html
install -o root -g root -m 0644 "$stage/site/sw.js" /srv/gg-panel/site/sw.js
install -o root -g root -m 0644 "$stage/server.mjs" /srv/gg-panel/server.mjs
install -o root -g root -m 0644 "$stage/inventory.mjs" /srv/gg-panel/inventory.mjs

systemctl restart gg-panel.service
for _ in {1..15}; do
  if curl -fsS http://127.0.0.1:3012/health >/dev/null; then break; fi
  sleep 1
done
systemctl is-active --quiet gg-panel.service
curl -fsS http://127.0.0.1:3012/health
sha256sum /srv/gg-panel/site/index.html /srv/gg-panel/site/sw.js
echo "BACKUP=$backup"
rm -f "$release"
