#!/bin/sh
set -eu
id gg-panel >/dev/null 2>&1 || useradd --system --home-dir /var/lib/gg-panel --shell /usr/sbin/nologin gg-panel
install -d -m 700 -o gg-panel -g gg-panel /var/lib/gg-panel
install -m 644 /srv/gg-panel/deploy/gg-panel.service /etc/systemd/system/gg-panel.service
install -m 644 /srv/gg-panel/deploy/gg-panel-cert-renew.service /etc/systemd/system/gg-panel-cert-renew.service
install -m 644 /srv/gg-panel/deploy/gg-panel-cert-renew.timer /etc/systemd/system/gg-panel-cert-renew.timer
printf '#!/bin/sh\n/usr/sbin/nginx -t && /usr/bin/systemctl reload nginx\n' > /usr/local/sbin/gg-panel-reload-nginx
chmod 755 /usr/local/sbin/gg-panel-reload-nginx
install -m 644 /srv/gg-panel/deploy/nginx.conf /etc/nginx/sites-available/gg-panel
nginx -t
systemctl daemon-reload
systemctl enable --now gg-panel
systemctl restart gg-panel
systemctl enable --now gg-panel-cert-renew.timer
systemctl reload nginx
systemctl is-active gg-panel gg-panel-cert-renew.timer
