#!/bin/bash
set -euo pipefail
target=/srv/gg-panel/site
stamp=$(date -u +%Y%m%dT%H%M%SZ)
backup=/srv/gg-panel-backups/control-$stamp
stage=/srv/gg-panel-control-$stamp
expected=676ee6681c754bb7d84d2c9258abfa6a0cc54d268f0df8fe0f732b565c8355f1
test "$(sha256sum "$target/index.html" | cut -d' ' -f1)" = "$expected"
install -d -m 0700 "$backup" "$stage"
tar -xzf /tmp/gg-control-20260905-control4.tar.gz -C "$stage"
test -f "$stage/index.html"
node --check "$stage/sw.js"
python3 -c 'from pathlib import Path; import sys; p=Path(sys.argv[1]); s=(p/"index.html").read_text(); assert "2026-09-05-control-4" in s and "workspace-hero" in s and "overview-view" in s and "business_metrics" in s; assert "2026-09-05-control-4" in (p/"sw.js").read_text()' "$stage"
cp -p "$target/index.html" "$target/sw.js" "$backup/"
rollback() {
  cp -p "$backup/index.html" "$target/index.html"
  cp -p "$backup/sw.js" "$target/sw.js"
  printf 'Previous panel restored from %s\n' "$backup"
}
trap rollback ERR
install -m 0644 -o root -g root "$stage/index.html" "$target/.index-control-next"
mv "$target/.index-control-next" "$target/index.html"
install -m 0644 -o root -g root "$stage/sw.js" "$target/.sw-control-next"
mv "$target/.sw-control-next" "$target/sw.js"
curl -fsS --max-time 10 http://127.0.0.1:3012/health > "$stage/health.json"
python3 -c 'import json,sys; assert json.load(open(sys.argv[1]))["ok"]' "$stage/health.json"
curl -fsS --max-time 10 --resolve 201.51.20.34:443:127.0.0.1 https://201.51.20.34/ > "$stage/served.html"
cmp "$stage/served.html" "$target/index.html"
sha256sum "$target/index.html" "$target/sw.js"
systemctl is-active gg-panel
printf 'BACKUP=%s\n' "$backup"
trap - ERR
