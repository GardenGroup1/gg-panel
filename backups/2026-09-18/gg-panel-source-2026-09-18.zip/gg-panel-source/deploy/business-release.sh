#!/bin/bash
set -euo pipefail
target=/srv/gg-panel
stamp=$(date -u +%Y%m%dT%H%M%SZ)
backup=/srv/gg-panel-backups/business-$stamp
stage=/srv/gg-panel-release-$stamp
test "$(sha256sum "$target/server.mjs" | cut -d' ' -f1)" = "9332ac53a67667e454d88e47029fda375efd8fbe03879fd41735e2329f6ec982"
install -d -m 0700 "$backup/site" "$stage"
tar -xzf /tmp/gg-business-release.tar.gz -C "$stage"
node --check "$stage/server.mjs"
python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); assert d["schema"]==1 and len(d["blocks"])==9' "$stage/business-data.json"
cp -p "$target/server.mjs" "$backup/"
cp -p "$target/site/index.html" "$target/site/sw.js" "$target/site/manifest.json" "$backup/site/"
if test -f "$target/business-data.json"; then cp -p "$target/business-data.json" "$backup/"; fi
rollback() {
  cp -p "$backup/server.mjs" "$target/server.mjs"
  cp -p "$backup/site/"* "$target/site/"
  if test -f "$backup/business-data.json"; then cp -p "$backup/business-data.json" "$target/"; fi
  systemctl restart gg-panel
  printf 'Release failed; previous code restored from %s\n' "$backup"
}
trap rollback ERR
install -m 0640 -o root -g gg-panel "$stage/business-data.json" "$target/business-data.json"
install -m 0644 -o root -g root "$stage/server.mjs" "$target/server.mjs"
systemctl restart gg-panel
for attempt in 1 2 3 4 5; do
  if curl -fsS --max-time 5 http://127.0.0.1:3012/health > "$stage/health.json"; then break; fi
  sleep 1
done
python3 -c 'import json,sys; assert json.load(open(sys.argv[1]))["ok"]' "$stage/health.json"
install -m 0644 -o root -g root "$stage/site/index.html" "$target/site/index.html"
install -m 0644 -o root -g root "$stage/site/manifest.json" "$target/site/manifest.json"
install -m 0644 -o root -g root "$stage/site/sw.js" "$target/site/sw.js"
curl -fsS --max-time 5 -H 'Content-Type: application/json' --data '{"action":"business_metrics"}' http://127.0.0.1:3012/api > "$stage/auth.json"
python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); assert d["code"]=="auth" and "report" not in d' "$stage/auth.json"
systemctl is-active gg-panel
stat -c '%a %U:%G %n' "$target/business-data.json"
sha256sum "$target/server.mjs" "$target/site/index.html" "$target/site/sw.js" "$target/site/manifest.json" "$target/business-data.json"
printf 'BACKUP=%s\n' "$backup"
trap - ERR
