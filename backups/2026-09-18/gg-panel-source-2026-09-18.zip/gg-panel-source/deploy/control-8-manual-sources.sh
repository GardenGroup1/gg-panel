#!/usr/bin/env bash
set -Eeuo pipefail

release=/tmp/gg-panel-control-8.tar.gz
stage=/tmp/gg-panel-control-8
expected_current=c76f23eb35799f9a4dee1f5a81393a79250942dddd201e6f5b65bedeeb77445c

test "$(sha256sum /srv/gg-panel/site/index.html | cut -d' ' -f1)" = "$expected_current"
test -f "$release"
rm -rf "$stage"
mkdir -p "$stage"
tar -xzf "$release" -C "$stage"
grep -q '2026-09-05-control-8' "$stage/site/index.html"
grep -q '2026-09-05-control-8' "$stage/site/sw.js"
grep -q 'const metricsAutoRefresh=false' "$stage/server.mjs"
grep -q 'Автоматическое обновление отключено' "$stage/site/index.html"
if grep -q 'Источник обновляется каждые' "$stage/site/index.html"; then exit 1; fi
node --check "$stage/server.mjs"
node --check "$stage/postgres.mjs"
node --check "$stage/inventory.mjs"
node --check "$stage/refresh-live-sources.mjs"

stamp=$(date -u +%Y%m%dT%H%M%SZ)
backup=/srv/gg-panel-backups/manual-sources-$stamp
mkdir -p "$backup/site" "$backup/data"
cp -a /srv/gg-panel/site/index.html /srv/gg-panel/site/sw.js "$backup/site/"
cp -a /srv/gg-panel/server.mjs /srv/gg-panel/postgres.mjs /srv/gg-panel/inventory.mjs "$backup/"
for file in postgres-metrics.json inventory-metrics.json; do
  if test -f "/var/lib/gg-panel/$file"; then cp -a "/var/lib/gg-panel/$file" "$backup/data/"; fi
done

install -o root -g root -m 0644 "$stage/postgres.mjs" /srv/gg-panel/postgres.mjs
install -o root -g root -m 0644 "$stage/inventory.mjs" /srv/gg-panel/inventory.mjs
install -o root -g root -m 0644 "$stage/refresh-live-sources.mjs" /srv/gg-panel/refresh-live-sources.mjs
set -a
. /etc/gg-panel-postgres.env
set +a
export DATA_DIR=/var/lib/gg-panel
runuser -u gg-panel -- /usr/bin/node /srv/gg-panel/refresh-live-sources.mjs
test -s /var/lib/gg-panel/postgres-metrics.json
test -s /var/lib/gg-panel/inventory-metrics.json

install -o root -g root -m 0644 "$stage/site/index.html" /srv/gg-panel/site/index.html
install -o root -g root -m 0644 "$stage/site/sw.js" /srv/gg-panel/site/sw.js
install -o root -g root -m 0644 "$stage/server.mjs" /srv/gg-panel/server.mjs

systemctl restart gg-panel.service
for _ in {1..15}; do
  if curl -fsS http://127.0.0.1:3012/health >/dev/null; then break; fi
  sleep 1
done
systemctl is-active --quiet gg-panel.service
curl -fsS http://127.0.0.1:3012/health
sha256sum /srv/gg-panel/site/index.html /srv/gg-panel/site/sw.js /srv/gg-panel/server.mjs /srv/gg-panel/postgres.mjs /srv/gg-panel/inventory.mjs
stat -c '%U:%G %a %n' /var/lib/gg-panel/postgres-metrics.json /var/lib/gg-panel/inventory-metrics.json
echo "BACKUP=$backup"
rm -f "$release"
