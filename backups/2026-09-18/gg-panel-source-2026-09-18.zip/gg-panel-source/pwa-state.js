  appVersion: '__APP_VERSION__',
  appUpdateAvailable: false,
  initAppUpdates(){
    window.addEventListener('gg-panel-update', () => { this.appUpdateAvailable=true; });
    const url=new URL(location.href);
    if(url.searchParams.has('update')){
      url.searchParams.delete('update');
      history.replaceState(null,'',url.pathname+url.search+url.hash);
    }
  },
  updateApplication(){
    if(!navigator.onLine){this.toast('Для обновления приложения подключитесь к интернету.');return;}
    if(this.active || this.showCreate || this.inbox.some(item=>item._editing || item._sending)){
      this.toast('Сначала сохраните изменения и закройте форму задачи.');return;
    }
    const url=new URL(location.href);
    url.searchParams.set('update',Date.now().toString());
    location.assign(url.href);
  },
