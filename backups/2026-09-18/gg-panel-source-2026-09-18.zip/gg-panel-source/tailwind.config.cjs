const tailwind={};

  tailwind.config = {
    theme: { extend: {
      colors: {
        bg:'#F7F8F9', surface:'#FFFFFF', ink:'#1D2A24', muted:'#7A8380',
        deep:'#2B4A33', deep2:'#1F3A28', lime:'#A6C36F', limelight:'#EEF4E1',
        navy:'#3E5470', sage:'#9DB48C', sagelight:'#E8F1E8',
        lav:'#EEF0FA', mint:'#E8F1E8', sky:'#E8F1F8', blush:'#F5ECEF', cloud:'#ECECEC', sea:'#E6F0EE',
        mauve:'#A38FAE', iris:'#8A8DB8', steel:'#8FA6B4', silver:'#B7B2AE', berry:'#B24B8B',
        line:'#E9ECEE', label:'#5E8A5E'
      },
      fontFamily: {
        sans: ['Montserrat','system-ui','sans-serif'],
        serif: ['Montserrat','system-ui','sans-serif'],
        mono: ['JetBrains Mono','ui-monospace','monospace']
      },
      borderRadius: { DEFAULT:'12px', sm:'8px', md:'12px', lg:'16px', xl:'20px', '2xl':'24px', '3xl':'28px' },
      boxShadow: {
        soft: '0 2px 12px rgba(36,40,33,0.05)',
        softer: '0 1px 4px rgba(36,40,33,0.04)',
        lift: '0 8px 30px rgba(36,40,33,0.10)'
      }
    }}
  };

module.exports={...tailwind.config,content:[__dirname+"/content.html"]};
