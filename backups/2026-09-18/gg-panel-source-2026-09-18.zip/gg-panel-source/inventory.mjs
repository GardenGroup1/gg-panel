import {existsSync,readFileSync,writeFileSync,renameSync} from 'node:fs';
import {join} from 'node:path';

const DEFAULT_SPREADSHEET_ID='1DW9lIcJOGcJh7nAHwlAwwmtnpTaGd9lg7sIUUjDH6Bk';
const SHEET='📊 Свод общий';

const numeric=value=>{
  if(typeof value==='number')return Number.isFinite(value)?value:null;
  if(typeof value!=='string')return null;
  const parsed=Number(value.replace(/[^\d,.-]/g,'').replace(',','.'));
  return Number.isFinite(parsed)?parsed:null;
};
const rowLabel=row=>String(row?.[0]??'').trim();

function parseGviz(text){
  const match=String(text).match(/google\.visualization\.Query\.setResponse\((\{[\s\S]*\})\);?\s*$/);
  if(!match)throw Error('invalid_gviz');
  const payload=JSON.parse(match[1]);
  if(payload.status!=='ok'||!Array.isArray(payload.table?.rows))throw Error('invalid_gviz');
  return payload.table.rows.map(row=>(row.c||[]).map(cell=>cell?.v??null));
}

export function createInventoryMetrics({env=process.env,fetchImpl=fetch,now=Date.now,startTimer=false,interval=300000,dataDir=''}={}){
  const spreadsheetId=env.INVENTORY_SHEET_ID||DEFAULT_SPREADSHEET_ID;
  const snapshotFile=dataDir?join(dataDir,'inventory-metrics.json'):'';
  let report=null,lastError='',refreshing=null,lastAttempt=0,timer=null;
  if(snapshotFile&&existsSync(snapshotFile)){try{const saved=JSON.parse(readFileSync(snapshotFile,'utf8'));if(saved?.schema===1&&saved.kind==='inventory'&&saved.totals&&Array.isArray(saved.components))report=saved;}catch{}}
  function persistReport(){if(!snapshotFile||!report)return;writeFileSync(snapshotFile+'.tmp',JSON.stringify(report),{mode:0o600});renameSync(snapshotFile+'.tmp',snapshotFile);}
  const sourceUrl=`https://docs.google.com/spreadsheets/d/${spreadsheetId}/edit`;
  const dataUrl=`https://docs.google.com/spreadsheets/d/${spreadsheetId}/gviz/tq?sheet=${encodeURIComponent(SHEET)}&range=A1:F80&headers=0&tqx=out:json`;
  const find=(rows,label)=>rows.find(row=>rowLabel(row)===label);
  async function refresh(){
    if(refreshing)return refreshing;
    lastAttempt=now();
    refreshing=(async()=>{
      try{
        const response=await fetchImpl(dataUrl,{redirect:'follow',cache:'no-store',signal:AbortSignal.timeout(20000)});
        if(!response.ok)throw Error('http_'+response.status);
        const rows=parseGviz(await response.text());
        const physical=find(rows,'Грядки + все КП (полный физический учёт)');
        const beds=find(rows,'Грядки (детально)');
        const pots=find(rows,'КП0-КП13 (детально)');
        const alphabet=find(rows,'Алфавит 2026г (авторский свод)');
        const writeoff=find(rows,'Списание');
        const uniqueLabel=rows.findIndex(row=>rowLabel(row)==='ПОЗИЦИЙ УНИКАЛЬНЫХ');
        const uniqueItems=uniqueLabel>0?numeric(rows[uniqueLabel-1]?.[0]):null;
        const required=[physical?.[1],physical?.[2],physical?.[3],beds?.[2],beds?.[3],pots?.[2],pots?.[3],uniqueItems,alphabet?.[4],writeoff?.[2],writeoff?.[3]].map(numeric);
        if(required.some(value=>value==null))throw Error('missing_metrics');
        const [lines,plants,value,bedsPlants,bedsValue,potsPlants,potsValue,unique,missingPrices,writeoffPlants,writeoffValue]=required;
        if(plants!==bedsPlants+potsPlants||value!==bedsValue+potsValue)throw Error('totals_mismatch');
        report={schema:1,kind:'inventory',mode:startTimer?'online':'manual',updatePolicy:startTimer?'timer':'manual',title:'Актуальная инвентаризация Питомника',sourceUrl,sourceSheet:SHEET,
          sourcePeriod:String(rows[1]?.[0]||'Период указан в источнике'),refreshedAt:new Date(now()).toISOString(),refreshMinutes:startTimer?Math.round(interval/60000):null,
          basis:rowLabel(physical),totals:{lines,uniqueItems:unique,plants,value,missingPrices},
          components:[{id:'beds',label:'Грядки',lines:numeric(beds[1]),plants:bedsPlants,value:bedsValue},{id:'pots',label:'КП0–КП13',lines:numeric(pots[1]),plants:potsPlants,value:potsValue}],
          writeoff:{lines:numeric(writeoff[1]),plants:writeoffPlants,value:writeoffValue},
          notes:['Основа отчёта — полный физический учёт «Грядки + все КП», рекомендованный на сводном листе.','Показатель без цены относится к строкам «Алфавит 2026г» и не вычитается из физического количества.','Пульт читает только сводные ячейки; исходные позиции и листы инвентаризации не передаются в браузер.']};
        lastError='';persistReport();return true;
      }catch(error){lastError='Не удалось обновить актуальную инвентаризацию. Сохранённый срез остаётся доступен.';console.error('Inventory refresh failed:',error?.message||error?.name||'unknown');return false;}
    })().finally(()=>{refreshing=null});
    return refreshing;
  }
  function snapshotReply(){
    if(startTimer&&now()-lastAttempt>=interval&&!refreshing)void refresh();
    if(!report)return {ok:false,code:refreshing?'warming':'unavailable',error:lastError||'Сервер получает актуальную инвентаризацию из Google Sheets.'};
    return {ok:true,report,stale:!!lastError||(startTimer&&now()-Date.parse(report.refreshedAt)>interval*2),warning:lastError,syncing:!!refreshing,manual:!startTimer};
  }
  if(startTimer){void refresh();timer=setInterval(()=>void refresh(),interval);timer.unref();}
  return {refresh,snapshotReply,close(){if(timer)clearInterval(timer);}};
}
