(() => {
  if (!('serviceWorker' in navigator) || location.protocol === 'file:') return;
  const version='__APP_VERSION__';
  const notify=()=>window.dispatchEvent(new Event('gg-panel-update'));
  navigator.serviceWorker.addEventListener('message',event=>{
    if(event.data?.type==='GG_PANEL_UPDATE_READY' && event.data.version!==version)notify();
  });
  let registrationPromise, lastCheck=0;
  async function check(){
    if(document.hidden || !navigator.onLine || Date.now()-lastCheck<60000)return;
    lastCheck=Date.now();
    try{
      registrationPromise ||= navigator.serviceWorker.register('sw.js',{updateViaCache:'none'});
      const registration=await registrationPromise;
      await registration.update();
    }catch(error){registrationPromise=null;console.warn('Обновление приложения недоступно:',error.message);}
  }
  window.addEventListener('load',check);
  window.addEventListener('pageshow',check);
  window.addEventListener('online',check);
  document.addEventListener('visibilitychange',check);
})();
