  academyData:null,academyLoading:false,academyError:'',academyOffline:false,academyTab:'overview',academySourceId:null,
  academyTabs:[{id:'overview',label:'Обзор'},{id:'products',label:'Продукты'},{id:'sales',label:'Отдел продаж'},{id:'marketing',label:'Маркетинг'},{id:'audience',label:'Аудитория'},{id:'learning',label:'Обучение'},{id:'finance',label:'Финансы'},{id:'sources',label:'Источники'},{id:'connections',label:'Автоданные'}],
  academyNumber(v){return v==null?'—':new Intl.NumberFormat('ru-RU',{maximumFractionDigits:2}).format(v);},
  academyMoney(v){return v==null?'—':this.academyNumber(v)+' ₽';},
  academyMoneyShort(v){return v>=1000000?new Intl.NumberFormat('ru-RU',{minimumFractionDigits:2,maximumFractionDigits:2}).format(v/1000000)+' млн ₽':this.academyMoney(v);},
  academyPercent(v){return v==null?'—':this.academyNumber(v)+'%';},
  academyRatio(a,b){return b>0?a/b*100:null;},
  academyBar(a,b){return Math.max(0,Math.min(100,b>0?a/b*100:0));},
  signalStyle(value,target=100){
    const n=Number(value),goal=Number(target);
    if(!Number.isFinite(n)||!Number.isFinite(goal)||goal<=0)return '--signal:#64748b;--signal-soft:#eef2f6;--signal-mid:#d5dde7;--signal-ink:#364152';
    const score=Math.max(0,Math.min(1,n/goal));
    const stops=score<.7?[[166,52,75],[203,143,43],score/.7]:[[203,143,43],[55,132,79],(score-.7)/.3];
    const rgb=stops[0].map((v,i)=>Math.round(v+(stops[1][i]-v)*stops[2]));
    return `--signal:rgb(${rgb.join(',')});--signal-soft:rgba(${rgb.join(',')},.13);--signal-mid:rgba(${rgb.join(',')},.28);--signal-ink:rgb(${rgb.map(v=>Math.max(32,Math.round(v*.72))).join(',')})`;
  },
  relativeSignalStyle(value,values){
    const list=(values||[]).map(Number).filter(Number.isFinite),n=Number(value);
    if(!Number.isFinite(n)||!list.length)return this.signalStyle(null);
    const lo=Math.min(...list),hi=Math.max(...list),score=hi===lo?70:(n-lo)/(hi-lo)*100;
    return this.signalStyle(score,100);
  },
  signalLabel(value,target=100){if(value==null||!Number.isFinite(Number(value))||!(target>0))return 'План не задан';const ratio=Number(value)/target;return ratio>=1?'План выполнен':ratio>=.7?'Близко к плану':'Ниже 70% плана';},
  metricPercent(value){const n=typeof value==='number'?value:Number(String(value??'').replace('−','-').replace(/[^\d,.-]/g,'').replace(',','.'));return Number.isFinite(n)?n:null;},
  signedSignalStyle(value){const n=this.metricPercent(value);return n==null?this.signalStyle(null):n>0?this.signalStyle(100):n===0?this.signalStyle(70):this.signalStyle(0);},
  academySource(id){return this.academyData?.sources.find(s=>s.id===id)||{};},
  get academySelectedSource(){return this.academySourceId?this.academySource(this.academySourceId):null;},
  get academyLive(){const r=this.academyData?.liveGetcourse?.report;return r && r.from===this.academyData.period.from && r.to===this.academyData.period.to?r:null;},
  get academyTrafficRows(){
    const rows=this.academyData?.getcourse?.traffic?.selected_channel_rows||[];
    return rows.map(r=>({...r,registrationRate:r.visitors>0?r.registrations/r.visitors*100:null}));
  },
  get academyCards(){
    const d=this.academyData;if(!d)return [];
    const live=this.academyLive,status=d.liveGetcourse?.status;
    const liveLabel=(status?.error || this.academyOffline || !this.online?'GetCourse · сохранено ':'Автоданные · ')+this.gcDate(status?.lastSync?.slice(0,10));
    return [
      {label:'Академия · результат по отчёту',value:this.academyMoney(d.sales.academy),short:this.academyMoneyShort(d.sales.academy),detail:'План '+this.academyMoney(d.sales.plan)+' · '+this.academyPercent(this.academyRatio(d.sales.academy,d.sales.plan)),source:'op',primary:true,badge:'Из отчёта · статично'},
      {label:'Отдел продаж · результат',value:this.academyMoney(d.sales.department),short:this.academyMoneyShort(d.sales.department),detail:this.academyPercent(this.academyRatio(d.sales.department,d.sales.plan))+' от плана ОП',source:'op',badge:'Из отчёта · статично'},
      {label:live?'GetCourse · полученные платежи':'GetCourse · принято в интерфейсе',value:this.academyMoney(live?.summary.receivedAmount??d.getcourse.payments.accepted_sum_rub_displayed),short:this.academyMoneyShort(live?.summary.receivedAmount??d.getcourse.payments.accepted_sum_rub_displayed),detail:this.academyNumber(live?.summary.paymentCount??d.getcourse.payments.accepted_count_displayed)+' платежей · созданы в августе',source:'gc-payments',badge:live?liveLabel:'Проверено в GetCourse · срез',live:!!live},
      {label:'GetCourse · платные заказы',value:this.academyNumber(live?.summary.orders??d.getcourse.orders.paid_offers_orders),detail:this.academyNumber(live?.summary.paidOrders??d.getcourse.orders.ui_fully_paid_orders)+(live?' завершены':' с отметкой оплаты')+' · созданы в августе',source:'gc-orders',badge:live?liveLabel:'Проверено в GetCourse · срез',live:!!live}
    ];
  },
  selectAcademyTab(id){
    if(!this.academyTabs.some(t=>t.id===id))return;
    this.academyTab=id;history.replaceState(null,'','#metrics'+(id==='overview'?'':'/'+id));
    if(id==='connections')this.loadGetCourse();
  },
  restoreAcademy(){
    try{const saved=JSON.parse(storage.get(STORAGE_PREFIX+'academy')||'null');if(saved?.schema===1 && Array.isArray(saved.sources)){this.academyData=saved;this.academyOffline=true;}}catch{}
  },
  async loadAcademy(){
    if(!this.authed||this.academyLoading)return;
    if(!navigator.onLine){this.academyOffline=true;return;}
    this.academyLoading=true;this.academyError='';
    try{
      const r=await api('academy_metrics');if(!this.authed)return;
      if(!r.ok){this.academyError=r.error||'Не удалось загрузить метрики.';this.academyOffline=!!this.academyData;return;}
      if(r.report?.schema!==1 || !Array.isArray(r.report.sources)){this.academyError='Формат данных изменился. Обновите страницу.';return;}
      this.academyData=r.report;this.academyOffline=false;
      if(!storage.set(STORAGE_PREFIX+'academy',JSON.stringify(r.report)))this.academyError='Данные загружены. Сохранить их на устройстве не удалось.';
    }finally{this.academyLoading=false;}
  },
  async refreshAcademy(){await Promise.all([this.loadAcademy(),this.loadGetCourse()]);},
