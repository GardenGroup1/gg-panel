import { createHash, randomUUID } from 'node:crypto';

const digest = value => createHash('sha256').update(value).digest('hex');
const error = (message, code = 'input') => ({ ok: false, code, error: message });

export function createCapture({ state, persist, createTask, normalize, directions, now = Date.now }) {
  state.inbox ||= [];
  state.captures ||= {};
  const running = new Set();
  // A process may have stopped after Google received a write. Never retry it blindly.
  let recovered = false;
  for (const item of state.inbox) if (item.state === 'saving') {
    item.state = 'uncertain'; item.warning = 'Сохранение прервалось. Проверьте список задач перед повтором.'; recovered = true;
  }
  if (recovered) persist();
  function result(item, repeated = false) {
    return { ok: true, status: item.state === 'accepted' ? 'created' : item.state === 'draft' ? 'inbox' : item.state,
      id: item.id, taskId: item.taskId || null, task: item.task, direction: item.direction,
      owner: item.owner, deadline: item.deadline, repeated, warning: item.warning || '', panelUrl: 'https://201.51.20.34/' };
  }
  function list() {
    return state.inbox.filter(i => ['draft','saving','uncertain'].includes(i.state)).map(i => ({
      id: i.id, task: i.task, direction: i.direction, owner: i.owner, deadline: i.deadline,
      block: i.block, size: i.size, prio: i.prio, state: i.state, warning: i.warning || '',
      source: i.source, sourceLabel: i.source === 'voice' ? 'Голосовое · Hermes' : 'Telegram · Hermes',
      rawText: i.rawText, receivedAt: i.receivedAt
    })).sort((a,b) => b.receivedAt.localeCompare(a.receivedAt));
  }
  function fields(body) {
    const f = { block: '—', owner: '', deadline: '', size: 'M', prio: 'C', ...normalize(body, true) };
    f.direction = body.direction || '';
    if (typeof f.direction !== 'string' || (f.direction && !directions.includes(f.direction))) throw Error('Укажите направление из списка панели.');
    if (f.deadline) {
      const m = /^(\d{2})\.(\d{2})\.(\d{4})$/.exec(f.deadline);
      const d = m && new Date(Date.UTC(+m[3], +m[2]-1, +m[1]));
      if (!m || d.getUTCDate() !== +m[1] || d.getUTCMonth() !== +m[2]-1 || d.getUTCFullYear() !== +m[3]) throw Error('Срок должен быть действительной датой дд.мм.гггг или пустым.');
    }
    delete f.status;
    return f;
  }
  async function submit(item, body, token) {
    if (item.state === 'accepted' || running.has(item.id)) return result(item, true);
    if (item.state === 'uncertain') return error('Google мог уже создать задачу. Проверьте список; автоматический повтор заблокирован.', 'uncertain');
    if (item.state === 'dismissed') return error('Запись убрана из Инбокса.');
    let f; try { f = fields(body); } catch (e) { return error(e.message); }
    if (!f.direction) return error('Выберите направление для задачи.');
    Object.assign(item, f, { state: 'saving', warning: '' });
    running.add(item.id); persist();
    try {
      const r = await createTask(f, token);
      if (r.ok && r.id) {
        item.state = 'accepted'; item.taskId = r.id; item.acceptedAt = new Date(now()).toISOString();
      } else if (['auth','stale','busy','input'].includes(r.code)) {
        // These errors happen before the Google write; the draft is safe to submit later.
        item.state = 'draft'; item.warning = r.error || 'Не удалось отправить в Google.';
      } else {
        item.state = 'uncertain'; item.warning = r.error || 'Google не подтвердил создание. Проверьте список задач.';
      }
      persist(); return result(item);
    } catch {
      item.state = 'uncertain'; item.warning = 'Нет подтверждения от Google. Проверьте список задач перед повтором.';
      persist(); return result(item);
    } finally { running.delete(item.id); }
  }
  async function capture(body) {
    const requestId = body.requestId;
    if (typeof requestId !== 'string' || requestId.length < 8 || requestId.length > 300) return error('Нужен постоянный идентификатор исходного сообщения.');
    let f; try { f = fields(body); } catch (e) { return error(e.message); }
    if (typeof body.rawText !== 'string' || !body.rawText.trim() || body.rawText.length > 20000) return error('Передайте исходный текст или расшифровку сообщения.');
    const requestKey = digest(requestId), payloadHash = digest(JSON.stringify({ ...f, rawText: body.rawText }));
    const prior = state.captures[requestKey];
    if (prior) {
      if (prior.payloadHash !== payloadHash) return error('Это сообщение уже записано с другими полями. Проверьте существующую запись.', 'conflict');
      const item = state.inbox.find(i => i.id === prior.id);
      return item ? result(item, true) : error('Не найдена сохранённая запись.', 'state');
    }
    const item = { ...f, id: 'in_' + randomUUID(), state: 'draft', rawText: body.rawText,
      source: body.source === 'voice' ? 'voice' : 'tg', receivedAt: new Date(now()).toISOString(), warning: '' };
    state.inbox.push(item); state.captures[requestKey] = { id: item.id, payloadHash }; persist();
    // Always capture first. Hermes clarifies direction, deadline and priority before submission.
    return result(item);
  }
  async function userAction(body) {
    const item = state.inbox.find(i => i.id === body.id);
    if (!item) return error('Запись не найдена.', 'not_found');
    if (body.action === 'inbox_accept') return submit(item, body, body.token);
    if (body.action === 'inbox_dismiss') {
      if (running.has(item.id)) return error('Подождите завершения сохранения.', 'busy');
      if (item.state !== 'accepted') item.state = 'dismissed';
      persist(); return { ok: true };
    }
    if (body.action === 'inbox_restore') {
      if (item.state === 'dismissed') item.state = item.warning ? 'uncertain' : 'draft';
      persist(); return result(item);
    }
    return error('Неизвестное действие.');
  }
  async function draftAction(body) {
    const item = state.inbox.find(i => i.id === body.id);
    if (!item) return error('Черновик не найден.', 'not_found');
    if (body.action === 'draft_get') return { ...result(item), rawText: item.rawText, size: item.size, prio: item.prio, block: item.block };
    if (body.action === 'draft_accept') {
      if (body.confirmed?.direction !== true || body.confirmed?.deadline !== true || body.confirmed?.prio !== true) return error('Сначала уточните у владельца направление, срок (или отсутствие срока) и приоритет.', 'clarification');
      return submit(item, { ...item, ...body });
    }
    if (body.action === 'draft_update') {
      if (item.state !== 'draft') return error('Этот черновик уже отправлен или требует проверки.', 'state');
      let f; try { f = fields({ ...item, ...body }); } catch (e) { return error(e.message); }
      Object.assign(item, f); persist(); return result(item);
    }
    return error('Неизвестное действие.');
  }
  return { capture, list, userAction, draftAction, status(requestId) {
    const prior = state.captures[digest(String(requestId || ''))];
    const item = prior && state.inbox.find(i => i.id === prior.id);
    return item ? result(item, true) : error('Такое сообщение ещё не сохранено.', 'not_found');
  } };
}
