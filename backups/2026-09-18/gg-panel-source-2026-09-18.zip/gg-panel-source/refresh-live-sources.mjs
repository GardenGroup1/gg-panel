import {mkdirSync} from 'node:fs';
import {createPostgresMetrics} from './postgres.mjs';
import {createInventoryMetrics} from './inventory.mjs';

const dataDir=process.env.DATA_DIR||'/var/lib/gg-panel';
mkdirSync(dataDir,{recursive:true,mode:0o700});
const calls=createPostgresMetrics({env:process.env,startTimer:false,dataDir});
const inventory=createInventoryMetrics({env:process.env,startTimer:false,dataDir});
try{
  const [callsOk,inventoryOk]=await Promise.all([calls.refresh(),inventory.refresh()]);
  const callReply=calls.snapshotReply(),inventoryReply=inventory.snapshotReply();
  if(!callsOk||!inventoryOk||!callReply.ok||!inventoryReply.ok)throw Error(JSON.stringify({calls:callReply.code||callsOk,inventory:inventoryReply.code||inventoryOk}));
  console.log(JSON.stringify({ok:true,calls:{through:callReply.report.range.through,rows:callReply.report.range.rows,refreshedAt:callReply.report.refreshedAt},inventory:{plants:inventoryReply.report.totals.plants,value:inventoryReply.report.totals.value,refreshedAt:inventoryReply.report.refreshedAt}}));
}finally{
  calls.close();inventory.close();
}
